#!/usr/bin/env python3
"""make_trajectory.py: one Markdown file holding the trajectory of one run of batch d2m (detectron2 on a commit of
nanolize, from nothing: a fresh host agent, two jobs, the parallel mode on), in the order things happened: every step
of the host session, every event and operation of the two jobs, every model session, every controller round, the
candidates and their comparisons, the requests of the check nodes. The sections follow the tqdm trajectories of
2026-11-20 (tqdm-runN-main-COMMIT-trajectory.md) and the detectron2 one of batch d2ab.

Read from the run's own records only (the host's saved session and its stream, the jobs' public records and operation
journals, the records of the model calls, the samples of the node requests, the launch record). Nothing is called,
nothing is changed. Paths of this machine, the account, the queue, node names, scheduler job numbers, the page key and
the repository owner's name are masked in what is written, and the text is checked for them before it is saved.

usage: make_trajectory.py OUT.md WORK_DIR RUN_DIR CLONE_GIT_DIR TITLE
  WORK_DIR       the archived working root (holds state/, model-calls/, issues.md)
  RUN_DIR        the experiment's record of the run (launch.txt, host.jsonl, host-prompt.txt, ns/, served-samples.jsonl)
  CLONE_GIT_DIR  the .git of the archived clone (for what changed between candidates)
  TITLE          what the nanolize commit is, in words (for the heading)"""
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path


def load(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return {} if default is None else default


def lines(path):
    found = []
    try:
        for line in Path(path).read_text(errors="replace").splitlines():
            try:
                found.append(json.loads(line))
            except ValueError:
                continue
    except OSError:
        pass
    return found


def stamp(value):
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError):
        return None


hms = lambda t: time.strftime("%H:%M:%S", time.gmtime(t)) if t else "–"
SECRET = {}  # what of this machine must not be written: filled from the run's own records in build()


def mask(text):
    """Nothing of this machine in what is written: its paths, the account, the queue, node names, job numbers, keys, names."""
    text = str(text)
    for old, new in SECRET["paths"]:
        text = text.replace(old, new)
    text = re.sub(r"((?:key|token|secret|password)[\"']?\s*[=:]\s*[\"']?)[A-Za-z0-9_\-]{16,}", r"\1<已隐去>", text, flags=re.I)
    text = re.sub(re.escape(SECRET["shared"]) + r"[A-Za-z0-9._/-]*", "<共享盘路径>", text)
    text = re.sub("-" + re.escape(SECRET["shared"].strip("/")) + r"-[A-Za-z0-9_-]*", "<会话目录名>", text)   # a path written with dashes (Claude Code's project folders)
    text = re.sub(re.escape(SECRET["shared"].rstrip("/")) + r"\b", "<共享盘>", text)                              # the filesystem named alone
    text = re.sub(r"/tmp/claude-\d+/[A-Za-z0-9._/-]+", "<临时目录>", text)
    text = text.replace(SECRET["home"], "~")
    for person in SECRET["people"]:
        text = text.replace(person, "<仓库所有者>")
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+\.(?:com|org|edu|net)\b", "<邮箱>", text)
    text = text.replace(SECRET["account"], "<账户>")
    text = re.sub(SECRET["queues"], "<队列>", text)
    text = text.replace(SECRET["user"], "<用户>")
    text = re.sub(SECRET["node"], "<节点>", text)
    text = re.sub(r"((?:[Ss]cheduler|batch|[Ss]lurm) job(?: id)?[ =:]+)\d{6,}", r"\1<调度作业>", text)
    text = re.sub(r"(\"(?:job_id|slurm_job)\": \")\d{6,}", r"\1<调度作业>", text)
    text = re.sub(r"(slurm_job=)\d+", r"\1<调度作业>", text)
    text = re.sub(r"(sbatch=)\S+", r"\1<调度器命令>", text)
    text = re.sub(r"(127\.0\.0\.1|localhost):\d{4,5}", r"\1:<端口>", text)
    for number in SECRET.get("numbers") or ():
        text = text.replace(number, "<调度作业>")
    return text


def one_line(text, limit):
    text = re.sub(r"\s+", " ", mask(text)).strip()
    return text if len(text) <= limit else text[:limit].rstrip() + " …"


cell = lambda text: str(text).replace("|", "\\|").replace("\n", " ")


def table(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join(" --- " for _ in head) + "|"]
    out += ["| " + " | ".join(cell(c) for c in row) + " |" for row in rows]
    return "\n".join(out) + "\n"


def details(summary, body, fence=""):
    return "<details><summary>%s</summary>\n\n```%s\n%s\n```\n\n</details>\n" % (summary, fence, body.replace("```", "'''"))


def read_job(job_dir):
    public, config = load(job_dir / "public.json"), load(job_dir / "config.json")
    events = public.get("events") or []
    return {"id": job_dir.name, "dir": job_dir, "public": public, "config": config, "events": events,
            "role": (config.get("pair") or {}).get("role") or "single", "entries": lines(job_dir / "operations.jsonl"),
            "first": stamp(events[0]["time"]) if events else None, "last": stamp(events[-1]["time"]) if events else None}


def git(git_dir, *args):
    try:
        out = subprocess.run(["git", "--git-dir", str(git_dir), "--no-pager", *args], capture_output=True, text=True, timeout=120)
        return out.stdout.rstrip() if out.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def host_session(run):
    """The host's saved session (the one whose first message is the run's prompt): its steps with their times."""
    best = None
    for path in sorted(Path(run, "ns", "claude-projects").glob("*/*.jsonl")):
        rows = lines(path)
        first = next((r for r in rows if r.get("type") == "user"), {})
        text = json.dumps((first.get("message") or {}).get("content"))
        if "host agent of an unattended nanolize run" in text and (best is None or len(rows) > len(best)):
            best = rows
    steps, review = [], None
    for row in best or []:
        if row.get("type") != "assistant" or row.get("isSidechain"):
            continue
        at = stamp(row.get("timestamp"))
        for block in (row.get("message") or {}).get("content") or []:
            if block.get("type") == "text" and block.get("text", "").strip():
                steps.append((at, "说", block["text"]))
            elif block.get("type") == "tool_use":
                name, given = block.get("name") or "", block.get("input") or {}
                short = re.sub(r"^mcp__plugin_nanolize_nanolize__", "nanolize:", name)
                if name.endswith("start_execution_review"):
                    review = given
                steps.append((at, "调用", (short, given)))
    return steps, review


def call_text(short, given):
    """One line for a tool call of the host: what it was for and the start of what it passed."""
    if short == "Bash":
        return "`Bash` %s：`%s`" % (one_line(given.get("description") or "", 160), one_line(given.get("command") or "", 420).replace("`", "'"))
    if short in ("Read", "Write", "Edit"):
        return "`%s` `%s`" % (short, one_line(given.get("file_path") or "", 200))
    if short == "Skill":
        return "`Skill` %s %s" % (given.get("skill"), one_line(given.get("args") or "", 300))
    if short == "ToolSearch":
        return "`ToolSearch` %s" % one_line(given.get("query") or "", 300).replace("mcp__plugin_nanolize_nanolize__", "")
    kept = {k: v for k, v in given.items() if k not in ("state_root", "run_id")}
    return "`%s` %s" % (short, one_line(json.dumps(kept, ensure_ascii=False), 520).replace("`", "'"))


def build(target, work, run, git_dir, title):
    jobs = [read_job(Path(p).parent) for p in sorted(Path(work, "state/jobs/jobs").glob("*/public.json"))]
    main = next(job for job in jobs if job["role"] == "main")
    draft = next(job for job in jobs if job["role"] == "draft")
    name = {main["id"]: "主", draft["id"]: "草稿"}
    zero = main["first"]
    plus = lambda t: "–" if t is None else "%.1f" % ((t - zero) / 60)
    launch = (run / "launch.txt").read_text()
    steps, args = host_session(run)
    args = args or {}
    executor = args.get("check_executor") or {}
    home = str(Path.home())
    shared = "/" + str(work).split("/")[1] + "/"                      # the shared filesystem the working root is on
    store = re.match(r"(.*)/archive/", str(work)).group(1)
    live = store + "/live"
    runtime = re.search(r"runtime=(\S+)", launch).group(1)
    people = set()
    for value in (git(git_dir, "log", "--all", "--format=%an%n%cn", "-30") or "").splitlines():
        if value.strip() and value.strip() not in ("nanolize",):
            people.add(value.strip())
    SECRET.update({
        "paths": [(live + "/nanolize-runs/detectron2/state/jobs/jobs/" + main["id"], "<主作业目录>"),
                  (live + "/nanolize-runs/detectron2/state/jobs/jobs/" + draft["id"], "<草稿作业目录>"),
                  (live + "/nanolize-runs/detectron2", "<工作根>"), (live + "/detectron2", "<原仓库>"),
                  (str(work), "<工作根>"), (runtime, "<nanolize 代码>"), (store + "/rtenv", "<nanolize 解释器>"),
                  (store + "/d2/env", "<测试环境>"), (store + "/d2/built", "<预编译扩展>")],
        "shared": shared, "home": home, "user": Path(home).name, "account": executor.get("account") or "\0",
        "queues": r"\b(?:%s|%s_(?:short|long|interactive))\b" % (re.escape(executor.get("partition") or "\0"), re.escape((executor.get("partition") or "\0").split("_")[0])),
        "node": r"\b[a-z]{2,6}\d?-\d{4,6}\b", "people": sorted(people, key=len, reverse=True),
    })
    raw = launch + " ".join(str(event.get("message")) for job in jobs for event in job["events"])
    SECRET["numbers"] = sorted(set(re.findall(r"(?:[Ss]cheduler job|slurm_job=)\s*(\d{6,})", raw)))
    result = main["public"].get("result") or {}
    size, sel, manifest = result.get("size") or {}, main["config"].get("selection") or {}, main["config"].get("manifest") or {}
    acceptance = result.get("acceptance") or {}

    ops, decisions = {}, []
    for job in (main, draft):
        ops[job["id"]] = [e for e in job["entries"] if e.get("kind") == "op"]
        decisions += [(job, e) for e in job["entries"] if e.get("kind") == "decision"]
    decisions.sort(key=lambda pair: stamp(pair[1].get("time")) or 0)
    op_start = lambda op: stamp(op.get("started_at"))
    done = lambda job, tool: [op for op in ops[job["id"]] if op.get("tool") == tool and op.get("duration_seconds") is not None and op.get("outcome") != "skipped"]

    # model calls
    calls = []
    for folder in sorted(Path(work, "model-calls").glob("*")):
        meta, res = load(folder / "metadata.json"), load(folder / "result.json")
        if not meta:
            continue
        space = str(meta.get("workspace") or "")
        found = re.search(r"/jobs/jobs/([0-9a-f]{32})/?(.*)$", space)
        trial = not found
        role = {"test_designer": "designer", "test_reviewer": "reviewer", "controller": "controller"}.get(meta.get("role"), "author" if meta.get("adapter") == "author" else meta.get("adapter"))
        where = "试调用的临时目录" if trial else re.sub(r"/?workspace$", "", found.group(2)) or "."
        usage = res.get("usage") or {}
        calls.append({"id": folder.name, "start": meta.get("started"), "seconds": res.get("seconds") or 0, "role": role, "trial": trial,
                      "job": found.group(1) if found else None, "where": where, "turns": res.get("turns"), "cost": res.get("cost_usd") or 0,
                      "input": usage.get("input_tokens") or 0, "output": usage.get("output_tokens") or 0, "cached": usage.get("cached_input_tokens") or 0,
                      "exit": res.get("exit_code"), "timed_out": res.get("timed_out")})
    calls.sort(key=lambda c: c["start"])
    real = [c for c in calls if not c["trial"]]
    trials = [c for c in calls if c["trial"]]

    seal = done(main, "seal_contract")[0]
    t_seal = op_start(seal) + seal["duration_seconds"]
    compares = done(main, "compare_behavior")
    t_first = op_start(compares[0])
    select = done(main, "select_candidate")[-1]
    t_select = op_start(select) + select["duration_seconds"]
    imported = done(main, "import_draft")[0]
    total = (main["last"] - zero) / 60
    replay = {}                                                           # the job's own totals: a test counts once, whatever the number of its leaves
    for group, counts in ((result.get("original_replay") or {}).get("summary") or {}).items():
        if isinstance(counts, dict):
            for key, value in counts.items():
                if isinstance(value, (int, float)):
                    replay[group + "." + key] = value
        elif isinstance(counts, (int, float)):
            replay[group] = counts
    designed = load(main["dir"] / "designed-tests.json")
    design_op = (done(main, "design_leaf_tests") or [{}])[0]
    design = design_op.get("result") or {}
    migration = designed.get("migration") or {}
    last_full = [op for op in compares if (op.get("result") or {}).get("scope") == "full"][-1]
    last_record = load(main["dir"] / "artifacts" / ((last_full["result"].get("artifact") or "") + ".json"))
    last_checks = last_record.get("checks") or []
    last_checks = last_checks if isinstance(last_checks, list) else list(last_checks.values())
    tally = {}
    for check in last_checks:
        tally[check.get("status")] = tally.get(check.get("status"), 0) + 1
    progress = result.get("rewrite_progress") or {}
    strategy = result.get("strategy") or {}
    claude = re.search(r"claude=(\S+)", launch).group(1)
    repo_commit = re.search(r"folder=\S+ commit=(\w+) branch=(\S+)", launch)
    started = stamp(re.search(r"started=(\S+)", launch).group(1))
    host_results = [e for e in lines(run / "host.jsonl") if e.get("type") == "result"]
    host_cost = (host_results[-1].get("total_cost_usd") or 0) if host_results else 0
    host_turns = sum(e.get("num_turns") or 0 for e in host_results)
    host_first, host_last = (steps[0][0], steps[-1][0]) if steps else (started, main["last"])
    parallel = (main["config"].get("strategy") or {}).get("parallel") or {}
    commit = git(git_dir, "log", "--format=%h %s", "-1", "main") or ""
    unverified = (last_full["result"].get("unverified") or {})
    not_run = sum(len(v) for v in unverified.values())

    w = []
    add = w.append
    add("# detectron2 压缩实验的轨迹：%s\n" % title)
    add("这份文件按时间顺序记录这次实验里发生的每一步：主持会话（host）的每一步、两个作业的每条事件和每个操作、每个模型会话、controller 的每一轮、每个候选和它的对比、检查节点接下的每个请求。"
        "内容全部取自这次运行自己的记录（主持会话保存的会话、作业的事件和操作记录、各次模型调用的记录、启动记录、运行期间对节点请求的抽样），由脚本生成；事件、工具返回和 controller 写的理由与指示是英文原文，照原样保留。"
        "时间都是 UTC，“第几分钟”从主作业的第一条事件算起（之前的为负数）。本机的路径、账户名、队列名、节点名、调度器作业编号、页面密钥和仓库所有者的姓名已经换成占位符。章节的排法和 2026-11-20 那几份 tqdm、detectron2 轨迹相同。\n")

    add("## 1. 配置和结果\n")
    add(table(["项目", "内容"], [
        ["实验", "用 nanolize 压缩 detectron2（`%s` @ `%s`），从零开始：主持会话自己做完整的阶段 01，得到的功能图有 %d 项能力、%d 条检查；选核心能力：选中 %d 项，排除 %d 项，留下 %s 条检查"
         % (repo_commit.group(2), repo_commit.group(1)[:7], len(manifest.get("capabilities") or []), len(manifest.get("checks") or []),
            len(manifest.get("capabilities") or []) - len(sel.get("excluded") or []), len(sel.get("excluded") or []),
            (done(main, "create_workspace")[0].get("result") or {}).get("retained_checks"))],
        ["nanolize 代码", "%s，版本 %s" % (title, (main["config"].get("runtime") or {}).get("version"))],
        ["选项", "`%s`；并行模式的设置（原样）`%s`；不做性能验收；行为修复上限用这个版本的默认值；检查经 nanolize 自己的执行器上计算节点"
         % (mask(re.search(r"args=(.*)", launch).group(1).strip()), json.dumps(parallel, ensure_ascii=False))],
        ["独立性", "不用任何早先运行的产物：detectron2 从公开仓库重新克隆到同一个提交；主持会话是全新的会话，功能图、清单、恢复的测试、runner 设置都由它重新做；"
                "整次运行在一个看不到早先运行文件（归档、包、运行记录、分析目录、Claude Code 的历史会话和记忆）的挂载命名空间里。测试环境和预编译的 C++ 扩展是实验前用脚本建好的机器环境，不是任何一次运行的产物，运行前后指纹相同"],
        ["主持会话", "Claude Code %s，Fable 5.2，effort high；%s UTC 启动，%s 提交作业（阶段 01 和提交共 %.1f 分钟），值守到 %s；%d 轮，$%.2f"
         % (claude, time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(started)), hms(zero), (zero - started) / 60, hms(host_last), host_turns, host_cost)],
        ["两个作业", "主作业 `%s`（冻结契约、验证、交付），草稿作业 `%s`（同时写第一版）" % (main["id"][:8], draft["id"][:8])],
        ["主作业起止", "%s – %s，%.1f 分钟（从批处理作业启动算起 %.1f 分钟）" % (hms(zero), hms(main["last"]), total, (main["last"] - started) / 60)],
        ["结束状态", "`%s`；缺口：%s" % (main["public"].get("status"), "、".join("`%s`" % g for g in acceptance.get("gaps") or []) or "无")],
        ["花费", "作业里的模型调用 $%.2f（%d 次），试调 $%.2f（%d 次），主持会话 $%.2f；合计 $%.2f"
         % (sum(c["cost"] for c in real), len(real), sum(c["cost"] for c in trials), len(trials), host_cost, sum(c["cost"] for c in calls) + host_cost)],
        ["体积", "%s → %s token，%.2f%%（目标 %.0f%%）" % (format(size.get("baseline_tokens") or 0, ","), format(size.get("total_tokens") or 0, ","), size.get("retained_percent") or 0, size.get("target_percent") or 0)],
        ["行为验收", "最后一次完整对比（`%s`）：%s；没有运行的检查 %d 条；行为修复 %s 次；controller 主作业 %s 轮、草稿作业 %d 轮"
         % (last_full["result"].get("artifact"), "、".join("%s %d 条" % kv for kv in sorted(tally.items(), key=lambda kv: str(kv[0]))), not_run,
            progress.get("repair_attempts"), strategy.get("rounds"), sum(1 for job, _ in decisions if job is draft))],
        ["安装检查", "状态 `%s`（%s / %s 步）" % ((result.get("installation") or {}).get("status"), (result.get("installation") or {}).get("checks_passed"), (result.get("installation") or {}).get("checks_total"))],
        ["原测试的迁移", "给了 %s 条，迁移成 %s 条；没能验证的 %s 条" % (migration.get("given"), migration.get("migrated"), migration.get("unverified"))],
        ["交付后回放原测试", "保留的 %d 个测试里回放 %d 个、交付版本通过 %d 个、退步 %d 个；和内部名字绑在一起的 %d 个里回放 %d 个、原版通过 %d 个、交付版本通过 %d 个"
         % (replay.get("kept.tests", 0), replay.get("kept.replayed", 0), replay.get("kept.candidate_passed", 0), replay.get("kept.regressed", 0),
            replay.get("coupled.tests", 0), replay.get("coupled.replayed", 0), replay.get("coupled.original_passed", 0), replay.get("coupled.candidate_passed", 0))],
    ]))

    add("## 2. 阶段\n")
    stages = [("主持会话的阶段 01 和提交（启动到主作业第一条事件）", started, zero), ("冻结（主作业开始到封存）", zero, t_seal),
              ("等草稿作业并导入（封存到第一次完整对比开始）", t_seal, t_first), ("对比与修复（到选定候选）", t_first, t_select), ("交付（到最后一条事件）", t_select, main["last"]),
              ("草稿作业（和冻结同时开始）", draft["first"], draft["last"]), ("主持会话在作业结束后的收尾", main["last"], host_last)]
    add(table(["阶段", "开始", "结束", "分钟"], [[label, hms(a), hms(z), "%.1f" % ((z - a) / 60)] for label, a, z in stages]))
    add("主作业封存后等了草稿作业 %.1f 分钟（`import_draft` 记下的等待）。这个版本的作业事件里不记检查节点的排队时间；节点接下每个请求的时间见第 8 节。\n" % ((imported.get("result") or {}).get("waited_seconds", 0) / 60))

    add("## 3. 主持会话的轨迹\n")
    add("主持会话是一个无人值守的 Claude Code 会话（`claude -p`，带 nanolize 插件），在计算节点上按 nanolize 的 skill 做完阶段 01、启动评审、提交选择，然后定时查看两个作业直到结束。"
        "下面依次是给它的提示、它传给 `start_execution_review` 的参数、它的每一步（调用了什么，说了什么；工具返回的内容不列）。\n")
    prompt = (run / "host-prompt.txt").read_text() if (run / "host-prompt.txt").exists() else ""
    add(details("给主持会话的提示（原文）", mask(prompt).strip()))
    add(details("启动记录", mask("\n".join(line[:400] for line in launch.splitlines())).strip()))
    add(details("传给 start_execution_review 的参数", mask(json.dumps(args, indent=1, ensure_ascii=False)), "json"))
    add(table(["时间", "第几分钟", "类型", "内容"],
              [[hms(at), plus(at), kind, one_line(what, 1500) if kind == "说" else call_text(*what)] for at, kind, what in steps]))
    if (work / "issues.md").exists():
        add(details("主持会话写的 issues.md（它在运行中记下的问题和决定，原文）", mask((work / "issues.md").read_text()).strip()))

    add("## 4. 两个作业的事件和操作（按时间）\n")
    add("“事件”是作业写给人看的进度消息；“操作”是作业执行的一步（工具名、结果、用时）；“controller”是 controller 的一轮决定。主作业和草稿作业的记录合在一起按时间排。\n")
    rows = []
    for job in (main, draft):
        for event in job["events"]:
            rows.append((stamp(event["time"]), name[job["id"]], "事件", ("`%s` " % "、".join(event["codes"]) if event.get("codes") else "") + one_line(event.get("message") or "", 900)))
        for op in ops[job["id"]]:
            took = "%.0f 秒" % op["duration_seconds"] if op.get("duration_seconds") is not None else "没有执行"
            extra = ""
            reason = (op.get("result") or {}).get("reason")
            if op.get("outcome") in ("invalid", "skipped", "not_triggered", "blocked") and reason:
                extra = "：" + one_line(reason, 400)
            rows.append((op_start(op), name[job["id"]], "操作", "`%s` → %s（%s）%s%s%s" % (
                op["tool"], op.get("outcome"), took, "，候选 %s" % op["candidate"] if op.get("candidate") else "",
                "，由 %s 发起" % op.get("caller") if op.get("caller") else "", extra)))
    for job, entry in decisions:
        res = entry.get("result") or {}
        rows.append((stamp(entry.get("time")), name[job["id"]], "controller", "第 %s 轮（%s，%.0f 秒，%d 个调用：%s）：%s" % (
            res.get("round"), entry.get("outcome"), res.get("duration_seconds") or 0, len(res.get("calls") or []),
            "、".join("`%s`" % call.get("tool") for call in res.get("calls") or []), one_line(res.get("reason") or "", 1200))))
    rows.sort(key=lambda row: row[0] or 0)
    add(table(["时间", "第几分钟", "作业", "类型", "内容"], [[hms(t), plus(t), job, kind, text] for t, job, kind, text in rows]))

    add("## 5. 模型会话（每次调用）\n")
    add("“位置”是这次调用在作业目录里的位置：`design/round-N/<叶子>` 是第 N 轮的测试设计者，`design/review…` 是评审者，`authoring` 是作者，"
        "`implementation-workspaces/workspace-…/authoring` 是并行组里的一个作者，`controller/NNNN` 是 controller 的第 N 轮。每个会话逐步的记录（每条命令和输出）不在这份文件里，在归档的 `model-calls/<编号>/events.jsonl`。\n")
    label = {"author": "作者", "controller": "controller", "designer": "测试设计者", "reviewer": "测试评审者"}
    add(table(["开始", "结束", "第几分钟", "作业", "角色", "位置", "秒", "轮数", "美元", "输入 token（含缓存）", "输出 token", "记录编号"],
              [[hms(c["start"]), hms(c["start"] + c["seconds"]), plus(c["start"]), name.get(c["job"], "–"), ("试调：" if c["trial"] else "") + label.get(c["role"], c["role"]), mask(c["where"]),
                "%.0f" % c["seconds"], c["turns"], "%.2f" % c["cost"], format(c["input"], ","), format(c["output"], ","), "`%s`" % c["id"][:8]] for c in calls]))
    by_role = {}
    for c in real:
        row = by_role.setdefault(c["role"], {"calls": 0, "cost": 0.0, "seconds": 0.0, "output": 0})
        row["calls"] += 1
        row["cost"] += c["cost"]
        row["seconds"] += c["seconds"]
        row["output"] += c["output"]
    add(table(["角色", "调用次数", "美元", "会话时间合计（分钟）", "输出 token"],
              [[label.get(role, role), row["calls"], "%.2f" % row["cost"], "%.1f" % (row["seconds"] / 60), format(row["output"], ",")] for role, row in by_role.items()]
              + [["合计（不含试调和主持会话）", len(real), "%.2f" % sum(c["cost"] for c in real), "%.1f" % (sum(c["seconds"] for c in real) / 60), format(sum(c["output"] for c in real), ",")]]))

    add("## 6. 测试设计和评审\n")
    sessions, committed = design.get("sessions") or {}, design.get("committed") or {}
    reasons = {}
    for item in designed.get("rejected") or []:
        code = (item.get("reasons") or ["?"])[0]
        reasons[code] = reasons.get(code, 0) + 1
    baselines = done(main, "capture_baseline")
    add(table(["项目", "数量"], [
        ["设计者会话 / 评审者会话", "%d / %d" % (sum(1 for c in real if c["role"] == "designer"), sum(1 for c in real if c["role"] == "reviewer"))],
        ["作业记下的会话数（原样）", "`%s`" % json.dumps(sessions, ensure_ascii=False)],
        ["提交到原版上的设计文件", "%s 个测试文件 + %s 个场景文件（性能文件 %s 个）" % (committed.get("tests"), committed.get("scenarios"), committed.get("performance"))],
        ["通过的文件", len(designed.get("accepted") or [])],
        ["被拒的文件（按原因）", "、".join("%s %d" % (k, v) for k, v in reasons.items()) or "无"],
        ["没有按评审意见改完的文件", len(designed.get("unrevised") or [])],
        ["原测试的迁移", "给了 %s 条，迁移成 %s 条，没法验证 %s 条" % (migration.get("given"), migration.get("migrated"), migration.get("unverifiable"))],
        ["两次基线的检查数", " → ".join(str((op.get("result") or {}).get("executed_checks")) for op in baselines)],
        ["第一次基线时没有有效测试的叶子", "、".join((baselines[0].get("result") or {}).get("leaves_without_valid_test") or []) or "无"],
        ["基线的问题（原文）", "；".join((baselines[-1].get("result") or {}).get("problems") or []) or "无"],
        ["封存时校验方持有的文件", (seal.get("result") or {}).get("protected_files")],
    ]))
    add("每个叶子的结果：\n")
    add(table(["叶子", "通过的测试文件", "通过的场景文件", "被拒的测试（按原因）", "被拒的场景（按原因）", "原测试迁移 / 没验证"],
              [[leaf.get("leaf"), leaf.get("accepted"), (leaf.get("scenarios") or {}).get("accepted"),
                "、".join("%s %d" % kv for kv in (leaf.get("rejected") or {}).items()) or "–",
                "、".join("%s %d" % kv for kv in ((leaf.get("scenarios") or {}).get("rejected") or {}).items()) or "–",
                "%s / %s" % ((leaf.get("migration") or {}).get("migrated", "–"), (leaf.get("migration") or {}).get("unverified", "–"))] for leaf in design.get("per_leaf") or []]))
    if designed.get("rejected"):
        add("被拒的文件和理由（原文的开头）：\n")
        add(table(["叶子", "轮", "文件", "理由"], [[r.get("capability"), r.get("round"), "`%s`" % r.get("path"), one_line("；".join(str(x) for x in r.get("reasons") or []), 420)] for r in designed["rejected"]]))
    if designed.get("not_migrated"):
        add("没有迁移成的原测试：\n")
        add(table(["原测试", "叶子", "状态", "设计者给的理由"], [["`%s`" % r.get("test"), r.get("capability"), r.get("state"), one_line(r.get("reason") or "", 420)] for r in designed["not_migrated"]]))
    caps = (seal.get("result") or {}).get("caps") or []
    if caps:
        add("封存时就定下的上限（这些缺口之后的工具关不掉，原样）：\n")
        add(table(["缺口", "原因", "涉及"], [[c.get("gap"), c.get("reason"), one_line(json.dumps({k: v for k, v in c.items() if k not in ("gap", "reason")}, ensure_ascii=False), 400)] for c in caps]))

    add("## 7. 候选、对比和修复\n")
    add("作者的每次调用。并行组（`run_parallel_agents`）里的每个请求是一个作者会话，各在自己的工作区里写，写完由程序合并：\n")
    mode = {"initial": "第一版", "behavior_repair": "行为修复", "performance_repair": "性能修复", "optimization": "体积优化"}
    by_space = {re.search(r"(workspace-[0-9a-f]+)", c["where"]).group(1): c for c in real if c["role"] == "author" and "workspace-" in c["where"]}
    authors = []
    for job in (draft, main):
        for op in ops[job["id"]]:
            if op.get("duration_seconds") is None or op.get("outcome") == "skipped":
                continue
            res, params, begin = op.get("result") or {}, op.get("params") or {}, op_start(op)
            if op["tool"] == "run_parallel_agents":
                asked = params.get("requests") or []
                for index, request in enumerate(res.get("requests") or []):
                    call = by_space.get(request.get("workspace_id"), {})
                    what = asked[index] if index < len(asked) else {}
                    changes = request.get("changes") or {}
                    overlap = ((request.get("original_overlap") or {}).get("call") or {}).get("percent")
                    authors.append([hms(call.get("start") or begin), plus(call.get("start") or begin), name[job["id"]], "并行组（%s）的请求 %s：%s" % (res.get("group"), request.get("request", index + 1), mode.get(request.get("mode"), request.get("mode"))),
                                    request.get("scope") or "、".join(what.get("capabilities") or []), "%.1f" % ((request.get("seconds") or 0) / 60), call.get("turns", "–"),
                                    "%.2f" % call["cost"] if call else "–", "+%s / 改 %s / 删 %s" % (changes.get("added"), changes.get("modified"), changes.get("removed")),
                                    request.get("candidate_id"), request.get("exit_code")])
                authors.append([hms(begin), plus(begin), name[job["id"]], "↑ 这个并行组整体（含合并）", "%d 个请求，冲突 %d 处" % (len(res.get("requests") or []), len(res.get("conflicts") or [])),
                                "%.1f" % (op["duration_seconds"] / 60), "–", "–", "–", res.get("candidate_id"), "–"])
            elif op["tool"] == "run_agent":
                call = next((c for c in real if c["role"] == "author" and "workspace-" not in c["where"] and c["job"] == job["id"] and begin - 5 <= c["start"] <= begin + op["duration_seconds"]), {})
                changes = res.get("changes") or {}
                authors.append([hms(begin), plus(begin), name[job["id"]], "单个作者：%s%s" % (mode.get(res.get("mode"), res.get("mode")), "（并行组之后的集成）" if params.get("role") == "implement" or res.get("mode") == "initial" else ""),
                                params.get("scope") or "、".join(params.get("capabilities") or []) or "整个选择", "%.1f" % (op["duration_seconds"] / 60), call.get("turns", "–"),
                                "%.2f" % call["cost"] if call else "–", "+%s / 改 %s / 删 %s" % (changes.get("added"), changes.get("modified"), changes.get("removed")), op.get("candidate") or "–", res.get("exit_code")])
    add(table(["开始", "第几分钟", "作业", "做什么", "范围或叶子", "分钟", "轮数", "美元", "文件（加 / 改 / 删）", "候选", "退出码"], authors))
    draft_import = result.get("draft_import") or {}
    if draft_import.get("calls"):
        add("作者会话读了多少原版、写出的代码和原版重合多少（作业在导入和修复时记下的，只测量、不拒绝）：\n")
        listed = [[name[draft["id"]], c.get("scope") or "–", "、".join(c.get("capabilities") or []), c.get("files"), c.get("opened"), "%s%%" % c.get("overlap_percent")] for c in draft_import["calls"]]
        listed += [[name[main["id"]], "修复", "、".join(c.get("capabilities") or []), c.get("files"), c.get("opened"), "%s%%" % c.get("overlap_percent")] for c in (result.get("source_reference") or {}).get("calls") or []]
        add(table(["作业", "范围", "叶子", "可查阅的原版文件", "打开过的", "和原版的重合"], listed))
    add("行为对比（都在主作业里；草稿作业计划的那一次因为主作业已经封存被跳过）：\n")
    add(table(["开始", "第几分钟", "范围", "候选", "分钟", "结果", "失败的检查", "没有运行的检查", "体积", "记录"],
              [[hms(op_start(op)), plus(op_start(op)), {"full": "完整", "targeted": "针对性"}.get(op["result"].get("scope"), op["result"].get("scope")), op.get("candidate"),
                "%.1f" % (op["duration_seconds"] / 60), op.get("outcome"), op["result"].get("failed_checks_total"),
                "；".join("%s: %s" % (k, "、".join(v)) for k, v in (op["result"].get("unverified") or {}).items()) or "–",
                "%.2f%%" % ((op["result"].get("size") or {}).get("retained_percent") or 0), "`%s`" % op["result"].get("artifact")] for op in compares]))
    for op in compares:
        record = load(main["dir"] / "artifacts" / ((op["result"].get("artifact") or "") + ".json"))
        checks = record.get("checks") or []
        checks = checks if isinstance(checks, list) else list(checks.values())
        failed = [c for c in checks if c.get("status") == "regressed"]
        if failed:
            add("`%s`（%s，%s对比）里没过的检查：\n" % (op["result"].get("artifact"), op.get("candidate"), {"full": "完整", "targeted": "针对性"}.get(op["result"].get("scope"))))
            listed = []
            for c in failed:
                before, now = (c.get("baseline") or {}).get("case_status") or {}, (c.get("current") or {}).get("case_status") or {}
                cases = sorted(k.split("::")[-1] for k, v in now.items() if v != before.get(k))
                listed.append(["`%s`" % c.get("name"), "、".join(c.get("capabilities") or []), "、".join("`%s`" % p for p in (c.get("test_nodes") or [])[:2]),
                               "、".join("`%s`" % k for k in cases[:8]) + (" 等 %d 个" % len(cases) if len(cases) > 8 else "") or "–"])
            add(table(["检查", "叶子", "测试文件", "结果变了的用例"], listed))
    installs = done(main, "check_installation")
    if installs:
        add("安装检查：\n")
        add(table(["开始", "第几分钟", "候选", "秒", "结果", "通过的步数"],
                  [[hms(op_start(op)), plus(op_start(op)), op.get("candidate"), "%.0f" % op["duration_seconds"], op.get("outcome"),
                    "%s / %s" % (op["result"].get("checks_passed"), op["result"].get("checks_total"))] for op in installs]))
    else:
        add("安装检查：这次没有配置（主持会话在 issues.md 第 7 条里写了原因），作业里没有运行过。\n")
    add("controller 的每一轮（理由和它交给作者的指示是原文）：\n")
    for job, entry in decisions:
        res = entry.get("result") or {}
        at = stamp(entry.get("time"))
        add("**%s作业第 %s 轮** · %s（第 %s 分钟）· %s · 用时 %.0f 秒 · %s token（其中缓存 %s）\n" % (
            name[job["id"]], res.get("round"), hms(at), plus(at), entry.get("outcome"), res.get("duration_seconds") or 0,
            format(res.get("tokens") or 0, ","), format(res.get("cached_input_tokens") or 0, ",")))
        add("- 它面对的建议：`%s`\n- 理由：%s\n- 它点的调用：\n" % (one_line(json.dumps(res.get("advice"), ensure_ascii=False), 400), one_line(res.get("reason") or "", 3000)))
        for index, call in enumerate(res.get("calls") or [], 1):
            params = dict(call.get("params") or {})
            instructions, requests = params.pop("instructions", None), params.pop("requests", None)
            add("  %d. `%s` %s%s\n" % (index, call.get("tool"), one_line(json.dumps(params, ensure_ascii=False), 900) if params else "",
                                       "（条件：%s）" % one_line(json.dumps(call.get("when") or call.get("after"), ensure_ascii=False), 200) if call.get("when") or call.get("after") else ""))
            if instructions:
                add("     " + details("交给作者的指示", "\n".join("     " + line for line in mask(instructions).splitlines())).replace("\n```", "\n     ```").replace("\n</details>", "\n     </details>"))
            for number, request in enumerate(requests or [], 1):
                request = dict(request)
                text = request.pop("instructions", "") or ""
                add("     - 请求 %d：`%s`\n" % (number, one_line(json.dumps(request, ensure_ascii=False), 500)))
                if text:
                    add("       " + details("交给这个作者的指示", "\n".join("       " + line for line in mask(text).splitlines())).replace("\n```", "\n       ```").replace("\n</details>", "\n       </details>"))
        if res.get("errors") or res.get("dropped"):
            add("- 被拒或丢掉的：`%s`\n" % one_line(json.dumps({"errors": res.get("errors"), "dropped": res.get("dropped")}, ensure_ascii=False), 900))
    commits = {}
    for op in ops[main["id"]]:
        binding = op.get("binding") or {}
        if binding.get("candidate") and binding.get("commit"):
            commits.setdefault(binding["candidate"], binding["commit"])
    ordered = sorted(commits.items(), key=lambda item: int(item[0].split("-")[1]))
    if len(ordered) > 1:
        add("主作业里相邻两个被对比过的候选之间改了什么：\n")
        for (a, ca), (b, cb) in zip(ordered, ordered[1:]):
            stat = git(git_dir, "diff", "--stat", ca, cb)
            add("%s → %s：\n\n```\n%s\n```\n" % (a, b, mask(stat) if stat else "（读不到）"))

    add("## 8. 节点申请\n")
    add("主作业的检查发到计算节点上跑（草稿作业的检查在它自己所在的机器上跑，不要节点）。这个版本的作业事件里不记节点的申请和排队，下面是运行期间每 10 秒抓一次得到的：每个分配接下的请求，时间是第一次看到的时间"
        "（`_run_checks` 是一批检查，`knockouts` 是敲除，`run_each` 是交付后回放原测试，带 `refused` 的是节点拒收）：\n")
    served = {}
    for entry in lines(run / "served-samples.jsonl"):
        if "served" in entry:
            row = served.setdefault(entry["batch"], {"items": []})
            row["items"].append((entry["time"], entry["served"]))
    add(table(["分配（作业/分配，各前 8 位）", "第一条请求", "最后一条请求", "接下的请求，按先后（第几分钟）"],
              [[key, "%s（第 %s 分钟）" % (hms(row["items"][0][0]), plus(row["items"][0][0])), "%s（第 %s 分钟）" % (hms(row["items"][-1][0]), plus(row["items"][-1][0])),
                "、".join("`%s`（%s）" % (what, plus(at)) for at, what in row["items"])] for key, row in served.items()]))

    add("## 9. 收尾\n")
    add("- 结束状态 `%s`：%s\n" % (main["public"].get("status"), one_line(result.get("summary") or "", 600)))
    add("- 选定并交付的候选：`%s`；行为验收 `%s`，体积验收 `%s`；主作业的作者尝试 %s 次（导入的第一版算 1 次，其中修复 %s 次）；结果分支上的提交 `%s`。\n" % (
        result.get("candidate"), progress.get("behavior_acceptance"), progress.get("size_acceptance"), progress.get("author_attempts"), progress.get("repair_attempts"), commits.get(result.get("candidate"), "–")))
    add("- 体积：原版 %s token（%s 行），交付 %s token（%s 行，%s 个源文件），保留 %.2f%%。\n" % (
        format(size.get("baseline_tokens") or 0, ","), format(size.get("baseline_source_lines") or 0, ","), format(size.get("total_tokens") or 0, ","),
        format(size.get("source_lines") or 0, ","), size.get("source_files"), size.get("retained_percent") or 0))
    add("- 缺口（作业的验收报告，原样）：\n")
    for gap in acceptance.get("gaps") or []:
        add("  - `%s`：`%s`\n" % (gap, one_line(json.dumps((acceptance.get("details") or {}).get(gap), ensure_ascii=False), 700)))
    add("- 不算验收标准的检查：`%s`\n" % one_line(json.dumps(result.get("not_criteria"), ensure_ascii=False), 400))
    for unknown in result.get("unknowns") or []:
        add("- controller 记下的未知项 `%s`（%s）：%s 卡在：%s\n" % (unknown.get("id"), unknown.get("status"), one_line(unknown.get("question") or "", 700), one_line(unknown.get("blocker") or "", 500)))
    add("- 交付后回放原测试：保留的 %d 个测试里回放 %d 个，原版通过 %d 个、交付版本通过 %d 个，退步 %d 个；和内部名字绑在一起的 %d 个里回放 %d 个，原版通过 %d 个、交付版本通过 %d 个，退步 %d 个。\n" % (
        replay.get("kept.tests", 0), replay.get("kept.replayed", 0), replay.get("kept.original_passed", 0), replay.get("kept.candidate_passed", 0), replay.get("kept.regressed", 0),
        replay.get("coupled.tests", 0), replay.get("coupled.replayed", 0), replay.get("coupled.original_passed", 0), replay.get("coupled.candidate_passed", 0), replay.get("coupled.regressed", 0)))
    add("  回放了 %d 个测试文件，另有 %d 个文件没有回放。\n" % (replay.get("files", 0), replay.get("files_not_replayed", 0)))
    add("- 草稿作业：结束状态 `%s`，%.1f 分钟；一个并行组写 %d 个范围，再一次集成。\n" % (
        draft["public"].get("status"), (draft["last"] - draft["first"]) / 60, sum(len((op.get("result") or {}).get("requests") or []) for op in done(draft, "run_parallel_agents"))))
    add("- 原仓库里主持会话提交的恢复测试：`%s`。\n" % one_line(commit, 200))
    for text in acceptance.get("limitations") or []:
        add("- 作业自己写的限制（原文）：%s\n" % one_line(text, 400))
    if host_results:
        add(details("主持会话的最后一条消息（原文）", mask(host_results[-1].get("result") or "").strip()))

    text = "\n".join(w)
    left = re.findall("|".join([re.escape(SECRET["user"][:6]) + r"\w*", "/home/", re.escape(shared), re.escape(SECRET["account"][:7]) + r"\w*", SECRET["queues"],
                                r"@[a-z0-9-]+\.(?:com|org|edu)\b", SECRET["node"], r"sk-ant-\w+", r"\b%d\b" % os.getuid(), "sbatch=/",
                                re.escape(SECRET["account"].replace("_", "-")), "-" + re.escape(shared.strip("/")) + "-", re.escape(shared.rstrip("/")) + r"\b",
                                *[re.escape(p) for p in SECRET["people"]], *SECRET["numbers"]]), text)
    assert not left, sorted(set(left))[:20]
    target.write_text(text, encoding="utf-8")
    print(target.name, len(text), "characters;", len(steps), "host steps;", len(rows), "events and operations;", len(calls), "model sessions;", len(decisions), "controller rounds;", len(served), "check allocations")


if __name__ == "__main__":
    build(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]), sys.argv[5])
