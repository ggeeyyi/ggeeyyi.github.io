#!/usr/bin/env python3
"""render_html.py: a trajectory Markdown file as one static HTML page (the site no longer renders Markdown itself:
since 2026-11-22 it is deployed by a workflow that copies the repository's files as they are).

usage: render_html.py IN.md OUT.html "TITLE" "DESCRIPTION" MD_NAME ZIP_NAME
The page follows the site's conventions (zh-CN, noindex, no referrer, the site's icon), reads in a light and a dark
theme, keeps every wide table inside its own scrolling box, and lists the sections at the top."""
import html
import re
import sys
from pathlib import Path

from markdown_it import MarkdownIt

ICON = ("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Crect width='16' height='16' rx='3' "
        "fill='%231c5cab'/%3E%3Cpath d='M4 11V5l8 6V5' fill='none' stroke='white' stroke-width='1.6'/%3E%3C/svg%3E")

CSS = """
:root { color-scheme: light; --bg:#f7f8fa; --card:#ffffff; --ink:#1b2230; --soft:#566074; --line:#dfe3ea; --head:#eef1f6;
  --accent:#1c5cab; --code:#f1f3f7; --mark:#fff6d6; }
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { color-scheme: dark; --bg:#12151b; --card:#1a1e26; --ink:#e4e8ef;
  --soft:#9aa5b8; --line:#2d3340; --head:#222834; --accent:#7fb0ee; --code:#222733; --mark:#3a3413; } }
:root[data-theme="dark"] { color-scheme: dark; --bg:#12151b; --card:#1a1e26; --ink:#e4e8ef; --soft:#9aa5b8; --line:#2d3340; --head:#222834;
  --accent:#7fb0ee; --code:#222733; --mark:#3a3413; }
html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }
body { margin: 0; background: var(--bg); color: var(--ink); font: 15px/1.65 -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
  "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif; }
main { max-width: 1180px; margin: 0 auto; padding: 28px 16px 80px; overflow-wrap: anywhere; }
h1 { font-size: 26px; line-height: 1.3; margin: 0 0 10px; letter-spacing: -0.01em; }
h2 { font-size: 20px; margin: 44px 0 12px; padding-top: 14px; border-top: 2px solid var(--line); scroll-margin-top: 12px; }
p { margin: 10px 0; }
a { color: var(--accent); }
.lead { color: var(--soft); font-size: 14px; }
.bar { display: flex; flex-wrap: wrap; gap: 8px; margin: 16px 0 6px; }
.bar a { display: inline-block; padding: 6px 12px; border: 1px solid var(--line); border-radius: 8px; background: var(--card); text-decoration: none; font-size: 14px; }
.bar a:hover { border-color: var(--accent); }
nav.toc { background: var(--card); border: 1px solid var(--line); border-radius: 10px; padding: 12px 16px; margin: 14px 0 8px; }
nav.toc b { font-size: 13px; color: var(--soft); font-weight: 600; }
nav.toc ol { margin: 6px 0 0; padding: 0; list-style: none; display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 2px 18px; }
nav.toc a { text-decoration: none; font-size: 14px; }
nav.toc a:hover { text-decoration: underline; }
.tw { overflow-x: auto; margin: 12px 0 16px; border: 1px solid var(--line); border-radius: 10px; background: var(--card); }
table { border-collapse: collapse; width: 100%; font-size: 13px; line-height: 1.5; }
th, td { padding: 6px 10px; border-bottom: 1px solid var(--line); border-right: 1px solid var(--line); text-align: left; vertical-align: top; }
th:last-child, td:last-child { border-right: 0; }
tr:last-child td { border-bottom: 0; }
th { background: var(--head); font-weight: 600; white-space: nowrap; position: sticky; top: 0; }
td { min-width: 3.2em; overflow-wrap: anywhere; }
td:last-child { min-width: 16em; }
td.n { white-space: nowrap; min-width: 0; }
tbody tr:hover td { background: var(--mark); }
code { font: 12.5px/1.5 ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace; background: var(--code); padding: 1px 5px; border-radius: 4px; overflow-wrap: anywhere; }
pre { background: var(--code); border: 1px solid var(--line); border-radius: 8px; padding: 12px 14px; margin: 8px 0 12px; overflow-x: auto;
  white-space: pre-wrap; overflow-wrap: anywhere; max-height: 560px; overflow-y: auto; }
pre code { background: none; padding: 0; font-size: 12.5px; }
details { margin: 8px 0; border: 1px solid var(--line); border-radius: 8px; background: var(--card); padding: 0 12px; }
details > summary { cursor: pointer; padding: 8px 0; color: var(--accent); font-size: 14px; }
details[open] > summary { border-bottom: 1px solid var(--line); margin-bottom: 8px; }
ul, ol { padding-left: 22px; }
li { margin: 4px 0; }
strong { font-weight: 650; }
footer { margin-top: 48px; color: var(--soft); font-size: 13px; border-top: 1px solid var(--line); padding-top: 12px; }
.top { position: fixed; right: 16px; bottom: 16px; padding: 7px 11px; border-radius: 8px; border: 1px solid var(--line); background: var(--card);
  text-decoration: none; font-size: 13px; box-shadow: 0 2px 8px rgba(0,0,0,.12); }
@media (max-width: 640px) { body { font-size: 14.5px; } h1 { font-size: 21px; } h2 { font-size: 18px; } table { font-size: 12.5px; } }
"""


def render(source, target, title, description, md_name, zip_name):
    text = Path(source).read_text(encoding="utf-8")
    body = MarkdownIt("commonmark", {"html": True}).enable("table").render(text)
    heading = re.search(r"<h1>(.*?)</h1>", body, flags=re.S)
    body = body.replace(heading.group(0), "", 1) if heading else body
    sections = []

    def anchor(match):
        number = len(sections) + 1
        sections.append((number, match.group(1)))
        return '<h2 id="s%d">%s</h2>' % (number, match.group(1))

    body = re.sub(r"<h2>(.*?)</h2>", anchor, body, flags=re.S)
    body = body.replace("<table>", '<div class="tw"><table>').replace("</table>", "</table></div>")
    # a short cell (a time, a number, a one-word label) stays on one line; long text wraps
    short = lambda m: '<td class="n">%s</td>' % m.group(1) if len(m.group(1).strip()) <= 9 and " " not in m.group(1).strip() else m.group(0)
    body = re.sub(r"<td>([^<]{1,12})</td>", short, body)
    lead, rest = body.split("<h2", 1) if "<h2" in body else ("", body)
    lead = lead.replace("<p>", '<p class="lead">')
    toc = "".join('<li><a href="#s%d">%s</a></li>' % (number, re.sub(r"<[^>]+>", "", name)) for number, name in sections)
    page = """<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="referrer" content="no-referrer">
<meta name="description" content="%s">
<title>%s</title>
<link rel="icon" href="%s">
<style>%s</style>
</head>
<body>
<main id="top">
<h1>%s</h1>
%s
<div class="bar"><a href="%s" download>下载 Markdown 原文件</a><a href="%s" download>下载 zip（轨迹和生成脚本）</a></div>
<nav class="toc"><b>章节</b><ol>%s</ol></nav>
<h2%s
<footer>这一页由脚本从同目录的 Markdown 文件生成，内容相同。本机的路径、账户名、队列名、节点名、调度器作业编号等已换成占位符。</footer>
</main>
<a class="top" href="#top">回到顶部</a>
</body>
</html>
""" % (html.escape(description, quote=True), html.escape(title), ICON, CSS, heading.group(1) if heading else html.escape(title), lead, md_name, zip_name, toc, rest)
    Path(target).write_text(page, encoding="utf-8")
    print(Path(target).name, len(page), "characters;", len(sections), "sections;", page.count("<table>"), "tables;", page.count("<details>"), "folded blocks;", page.count("<pre>"), "code blocks")


if __name__ == "__main__":
    render(*sys.argv[1:7])
