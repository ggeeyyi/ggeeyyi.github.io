#!/usr/bin/env python3
"""make_trajectory_r2.py: one Markdown file holding the trajectory of run r2 of batch d2m (detectron2 on a commit of
nanolize, from nothing, with performance acceptance on), as far as it has gone when this is called. Unlike r1
(make_trajectory.py) this run has: two pairs of jobs (the host cancelled the first pair and submitted a second), a
design that ran twice in the second main job (a pause in the freeze), an allocation that ended at its time limit and
a second allocation in which the host's session and the main job were resumed, and performance acceptance (benchmark
files in the freeze, a performance contract, measurements of the candidate). The run may still be going on.

Read from the run's own records only (the host's saved session and its streams, the jobs' public records and
operation journals, the records of the model calls, the samples of the node requests, the launch record), plus,
if given, a dump of the scheduler's accounting for the table of check batches. Nothing is called, nothing is
changed. Paths of this machine, the account, the queue, node names, scheduler job numbers, the page key and the
repository owner's name are masked in what is written, and the text is checked for them before it is saved.

usage: make_trajectory_r2.py OUT.md WORK_DIR RUN_DIR CLONE_GIT_DIR TITLE [SACCT_DUMP]
  WORK_DIR       the working root (holds state/, model-calls/, issues.md): the live one or an archived one
  RUN_DIR        the experiment's record of the run (launch.txt, host.jsonl, host-resume.jsonl, ns/, ...)
  CLONE_GIT_DIR  the .git of the clone (for what changed between candidates)
  TITLE          what the nanolize commit is, in words (for the heading)
  SACCT_DUMP     lines "JobID|JobName|Start|End|Elapsed|State" of the day's jobs (optional)"""
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

PST = 8 * 3600
DAY = [None]  # the run's first day (PST): a time of another day is written with its date
SECRET = {}   # what of this machine must not be written: filled from the run's own records in build()


def load(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return {} if default is None else default


def lines(path):
    found = []
    try:
        for line in Path(path).read_text(errors="replace").splitlines():
            try:
                found.append(json.loads(line))
            except ValueError:
                continue
    except OSError:
        pass
    return found


def stamp(value):
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError):
        return None


def hms(t):
    if not t:
        return "–"
    local = time.gmtime(t - PST)
    day = time.strftime("%m-%d", local)
    return time.strftime("%H:%M:%S", local) if day == DAY[0] else day + " " + time.strftime("%H:%M:%S", local)


def mask(text):
    """Nothing of this machine in what is written: its paths, the account, the queue, node names, job numbers, keys, names."""
    text = str(text)
    for old, new in SECRET["paths"]:
        text = text.replace(old, new)
    text = re.sub(r"/tmp/claude-\d+(?:/[A-Za-z0-9._/-]*)?", "<临时目录>", text)
    text = re.sub(r"((?:key|token|secret|password)[\"']?\s*[=:]\s*[\"']?)[A-Za-z0-9_\-]{16,}", r"\1<已隐去>", text, flags=re.I)
    text = re.sub(re.escape(SECRET["shared"]) + r"[A-Za-z0-9._/-]*", "<共享盘路径>", text)
    text = re.sub("-" + re.escape(SECRET["shared"].strip("/")) + r"-[A-Za-z0-9_-]*", "<会话目录名>", text)
    text = re.sub(re.escape(SECRET["shared"].rstrip("/")) + r"\b", "<共享盘>", text)
    text = text.replace(SECRET["home"], "~")
    text = re.sub("-" + re.escape(SECRET["home"].strip("/").replace("/", "-")) + r"[A-Za-z0-9_-]*", "<会话目录名>", text)
    for person in SECRET["people"]:
        text = text.replace(person, "<仓库所有者>")
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+\.(?:com|org|edu|net)\b", "<邮箱>", text)
    text = text.replace(SECRET["account"], "<账户>")
    text = re.sub(SECRET["queues"], "<队列>", text)
    text = text.replace(SECRET["user"], "<用户>")
    text = re.sub(SECRET["node"], "<节点>", text)
    text = re.sub(r"((?:[Ss]cheduler|batch|[Ss]lurm) job(?: id)?[ =:]+)\d{6,}", r"\1<调度作业>", text)
    text = re.sub(r"(\"(?:job_id|slurm_job)\": \")\d{6,}", r"\1<调度作业>", text)
    text = re.sub(r"(slurm_job=)\d+", r"\1<调度作业>", text)
    text = re.sub(r"(sbatch=)\S+", r"\1<调度器命令>", text)
    text = re.sub(r"(127\.0\.0\.1|localhost):\d{4,5}", r"\1:<端口>", text)
    text = re.sub(r"\b(by|uid[= ]) ?%d\b" % os.getuid(), r"\1 <用户编号>", text)
    for number in SECRET.get("numbers") or ():
        text = text.replace(number, "<调度作业>")
    return text


def one_line(text, limit):
    text = re.sub(r"\s+", " ", mask(text)).strip()
    return text if len(text) <= limit else text[:limit].rstrip() + " …"


cell = lambda text: str(text).replace("|", "\\|").replace("\n", " ")


def table(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join(" --- " for _ in head) + "|"]
    out += ["| " + " | ".join(cell(c) for c in row) + " |" for row in rows]
    return "\n".join(out) + "\n"


def details(summary, body, fence=""):
    return "<details><summary>%s</summary>\n\n```%s\n%s\n```\n\n</details>\n" % (summary, fence, body.replace("```", "'''"))


def folded(summary, body):
    """A collapsed block that holds Markdown (a table), not a code block."""
    return "<details><summary>%s</summary>\n\n%s\n</details>\n" % (summary, body)


def read_job(job_dir):
    public, config = load(job_dir / "public.json"), load(job_dir / "config.json")
    events = public.get("events") or []
    return {"id": job_dir.name, "dir": job_dir, "public": public, "config": config, "events": events,
            "role": (config.get("pair") or {}).get("role") or "single", "entries": lines(job_dir / "operations.jsonl"),
            "first": stamp(events[0]["time"]) if events else None, "last": stamp(events[-1]["time"]) if events else None}


def git(git_dir, *args):
    try:
        out = subprocess.run(["git", "--git-dir", str(git_dir), "--no-pager", *args], capture_output=True, text=True, timeout=120)
        return out.stdout.rstrip() if out.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def host_session(run):
    """The host's saved session (the one whose first message is the run's prompt): its steps with their times, and
    what it passed to start_execution_review each time."""
    best = None
    for path in sorted(Path(run, "ns", "claude-projects").glob("*/*.jsonl")):
        rows = lines(path)
        first = next((r for r in rows if r.get("type") == "user"), {})
        text = json.dumps((first.get("message") or {}).get("content"))
        if "host agent of an unattended nanolize run" in text and (best is None or len(rows) > len(best)):
            best = rows
    steps, reviews = [], []
    for row in best or []:
        if row.get("type") != "assistant" or row.get("isSidechain"):
            continue
        at = stamp(row.get("timestamp"))
        for block in (row.get("message") or {}).get("content") or []:
            if block.get("type") == "text" and block.get("text", "").strip():
                steps.append((at, "说", block["text"]))
            elif block.get("type") == "tool_use":
                name, given = block.get("name") or "", block.get("input") or {}
                short = re.sub(r"^mcp__plugin_nanolize_nanolize__", "nanolize:", name)
                if name.endswith("start_execution_review"):
                    reviews.append((at, given))
                steps.append((at, "调用", (short, given)))
    return steps, reviews


def call_text(short, given):
    """One line for a tool call of the host: what it was for and the start of what it passed."""
    if short == "Bash":
        return "`Bash` %s：`%s`" % (one_line(given.get("description") or "", 160), one_line(given.get("command") or "", 420).replace("`", "'"))
    if short in ("Read", "Write", "Edit"):
        return "`%s` `%s`" % (short, one_line(given.get("file_path") or "", 200))
    if short == "Skill":
        return "`Skill` %s %s" % (given.get("skill"), one_line(given.get("args") or "", 300))
    if short == "ToolSearch":
        return "`ToolSearch` %s" % one_line(given.get("query") or "", 300).replace("mcp__plugin_nanolize_nanolize__", "")
    kept = {k: v for k, v in given.items() if k not in ("state_root", "run_id")}
    return "`%s` %s" % (short, one_line(json.dumps(kept, ensure_ascii=False), 520).replace("`", "'"))


def build(target, work, run, git_dir, title, sacct=None):
    now = time.time()
    jobs = [read_job(Path(p).parent) for p in sorted(Path(work, "state/jobs/jobs").glob("*/public.json"))]
    jobs = sorted((job for job in jobs if job["first"]), key=lambda job: job["first"])
    mains = [job for job in jobs if job["role"] == "main"]
    by_id = {job["id"]: job for job in jobs}
    marks = "①②③④⑤"
    name, pairs = {}, []
    for index, job in enumerate(mains):
        partner = by_id.get((job["config"].get("pair") or {}).get("partner_job_id"))
        name[job["id"]] = "主" + (marks[index] if len(mains) > 1 else "")
        if partner:
            name[partner["id"]] = "草稿" + (marks[index] if len(mains) > 1 else "")
        pairs.append((job, partner))
    jobs = [job for job in jobs if job["id"] in name]
    main, draft = pairs[-1]            # the pair that goes on
    old = pairs[:-1]                   # pairs the host cancelled

    launch = (run / "launch.txt").read_text()
    started = stamp(re.search(r"started=(\S+)", launch).group(1))
    DAY[0] = time.strftime("%m-%d", time.gmtime(started - PST))
    zero = started
    plus = lambda t: "–" if t is None else "%.1f" % ((t - zero) / 60)
    span = lambda a, z: "%.1f" % ((z - a) / 60)
    steps, reviews = host_session(run)
    args = reviews[-1][1] if reviews else {}
    executor = args.get("check_executor") or main["config"].get("check_executor") or {}
    home = str(Path.home())
    shared = "/" + str(work).split("/")[1] + "/"
    store = re.match(r"(.*?)/(?:archive/.*|live)/nanolize-runs/", str(work) + "/").group(1)
    live = store + "/live"
    runtime = re.search(r"runtime=(\S+)", launch).group(1)
    people = set()
    for value in (git(git_dir, "log", "--all", "--format=%an%n%cn", "-30") or "").splitlines():
        if value.strip() and value.strip() not in ("nanolize",):
            people.add(value.strip())
    job_paths = []
    for job in jobs:
        for root in (live + "/nanolize-runs/detectron2", str(work)):
            job_paths.append((root + "/state/jobs/jobs/" + job["id"], "<%s作业目录>" % name[job["id"]]))
    SECRET.update({
        "paths": job_paths + [
            (live + "/nanolize-runs/detectron2", "<工作根>"), (live + "/detectron2", "<原仓库>"),
            (str(work), "<工作根>"), (runtime, "<nanolize 代码>"), (store + "/rtenv", "<nanolize 解释器>"),
            (store + "/d2/env", "<测试环境>"), (store + "/d2/built", "<预编译扩展>"),
            (str(Path(runtime).parents[1]), "<实验目录>"), (str(Path(runtime).parents[2]), "<检出目录>"),
            ("/" + Path(store).name + "/", "/<存储目录>/")],
        "shared": shared, "home": home, "user": Path(home).name, "account": executor.get("account") or "\0",
        "queues": r"\b(?:%s|%s_(?:short|long|interactive))\b" % (re.escape(executor.get("partition") or "\0"), re.escape((executor.get("partition") or "\0").split("_")[0])),
        "node": r"\b(?:cpu|gpu|login|node)\w{0,6}-\d{3,6}\b", "people": sorted(people, key=len, reverse=True),
    })
    raw = launch + " ".join(str(event.get("message")) for job in jobs for event in job["events"])
    numbers = set(re.findall(r"(?:[Ss]cheduler job|slurm_job=)\s*(\d{6,})", raw))
    for path in list(run.glob("sbatch*.jobid")) + list(Path(work, "state/jobs/jobs").glob("*/check-batches/*/job.json")):
        try:
            numbers.update(re.findall(r"\b\d{7,9}\b", path.read_text()))
        except OSError:
            pass
    accounting = []
    if sacct and Path(sacct).exists():
        for line in Path(sacct).read_text().splitlines():
            parts = line.split("|")
            if len(parts) >= 6:
                numbers.add(parts[0].split(".")[0].split("_")[0])
                if re.match(r"(d2m|nanolize-checks)", parts[1]):
                    accounting.append(parts)
    SECRET["numbers"] = sorted((n for n in numbers if n.isdigit() and len(n) >= 6), key=len, reverse=True)

    ops, decisions = {}, []
    for job in jobs:
        ops[job["id"]] = [e for e in job["entries"] if e.get("kind") == "op"]
        decisions += [(job, e) for e in job["entries"] if e.get("kind") == "decision"]
    decisions.sort(key=lambda pair: stamp(pair[1].get("time")) or 0)
    op_start = lambda op: stamp(op.get("started_at"))
    op_end = lambda op: op_start(op) + op["duration_seconds"]
    done = lambda job, tool: [op for op in ops[job["id"]] if op.get("tool") == tool and op.get("duration_seconds") is not None
                              and op.get("outcome") not in ("skipped", None)]

    # model calls
    calls = []
    for folder in sorted(Path(work, "model-calls").glob("*")):
        meta, res = load(folder / "metadata.json"), load(folder / "result.json")
        if not meta:
            continue
        space = str(meta.get("workspace") or "")
        found = re.search(r"/jobs/jobs/([0-9a-f]{32})/?(.*)$", space)
        trial = not found
        role = {"test_designer": "designer", "test_reviewer": "reviewer", "controller": "controller"}.get(meta.get("role"), "author" if meta.get("adapter") == "author" else meta.get("adapter"))
        where = "试调用的临时目录" if trial else re.sub(r"/?workspace$", "", found.group(2)) or "."
        usage = res.get("usage") or {}
        calls.append({"id": folder.name, "start": stamp(meta.get("started")), "seconds": res.get("seconds") or 0, "role": str(role), "trial": trial,
                      "job": found.group(1) if found else None, "where": where, "turns": res.get("turns"), "cost": res.get("cost_usd") or 0,
                      "input": usage.get("input_tokens") or 0, "output": usage.get("output_tokens") or 0, "cached": usage.get("cached_input_tokens") or 0,
                      "exit": res.get("exit_code"), "timed_out": res.get("timed_out"), "ended": bool(res)})
    calls.sort(key=lambda c: c["start"] or 0)
    real = [c for c in calls if not c["trial"]]
    trials = [c for c in calls if c["trial"]]
    cost_of = lambda job: sum(c["cost"] for c in real if job and c["job"] == job["id"])

    # the second main job's steps
    designs = [op for op in ops[main["id"]] if op.get("tool") == "design_leaf_tests" and op.get("duration_seconds") is not None]
    design_op = next((op for op in designs if op.get("outcome") == "done"), {})
    design = design_op.get("result") or {}
    designed = load(main["dir"] / "designed-tests.json")
    migration = designed.get("migration") or {}
    baselines = done(main, "capture_baseline")
    seals = done(main, "seal_contract")
    seal = seals[0] if seals else None
    imports = done(main, "import_draft")
    compares = done(main, "compare_behavior")
    full = [op for op in compares if (op.get("result") or {}).get("scope") == "full"]
    installs = done(main, "check_installation")
    measures = done(main, "compare_performance")
    contract = load(main["dir"] / "performance-contract.json")
    perf_settings = main["config"].get("performance") or {}
    manifest, sel = main["config"].get("manifest") or {}, main["config"].get("selection") or {}
    parallel = (main["config"].get("strategy") or {}).get("parallel") or {}
    claude = re.search(r"claude=(\S+)", launch).group(1)
    repo_commit = re.search(r"folder=\S+ commit=(\w+) branch=(\S+)", launch)
    host_results = [e for e in lines(run / "host.jsonl") if e.get("type") == "result"]
    resume_results = [e for e in lines(run / "host-resume.jsonl") if e.get("type") == "result"]
    host_cost = sum((e.get("total_cost_usd") or 0) for e in host_results[-1:]) + sum((e.get("total_cost_usd") or 0) for e in resume_results[-1:])
    host_turns = sum(e.get("num_turns") or 0 for e in host_results + resume_results)
    killed = re.search(r"CANCELLED AT (\S+) DUE TO TIME LIMIT", (run / "slurm.out").read_text(errors="replace") if (run / "slurm.out").exists() else "")
    t_killed = stamp(killed.group(1) + "-08:00") if killed else None
    resumed = re.search(r"resume: .*?started=(\S+)", launch)
    t_resumed = stamp(resumed.group(1)) if resumed else None
    host_exit = re.search(r"^host exit=\d+ at (\S+)", launch, re.M)
    t_host_exit = stamp(host_exit.group(1)) if host_exit else None
    resume_host = re.search(r"resume: host start (\S+)", launch)
    t_resume_host = stamp(resume_host.group(1)) if resume_host else None
    paused = next((e for e in main["events"] if e.get("phase") == "paused"), None)
    after_pause = next((e for e in main["events"] if paused and stamp(e["time"]) > stamp(paused["time"])), None)
    worker_lost = next((e for e in main["events"] if "execution worker stopped" in str(e.get("message"))), None)
    accepted_again = next((e for e in main["events"] if "Validated checkpoint accepted" in str(e.get("message"))), None)
    passed = next((op for op in full if op.get("outcome") == "checks_passed"), None)
    commit = git(git_dir, "log", "--format=%h %s", "-1", "main") or ""
    state_now = "`%s`（阶段 `%s`）" % (main["public"].get("status"), main["public"].get("phase"))
    over = main["public"].get("status") not in ("running", "queued", "paused", None)      # the main job has ended
    outcome = main["public"].get("result") or {}

    w = []
    add = w.append
    add("# detectron2 压缩实验的轨迹（开性能验收%s）：%s\n" % ("" if over else "，进行中", title))
    add("这份文件按时间顺序记录这次实验到 **%s（PST）** 为止发生的每一步：主持会话（host）的每一步、四个作业的每条事件和每个操作、每个模型会话、controller 的每一轮、每个候选和它的对比、性能契约和性能测量、检查节点接下的每个请求。"
        "%s\n" % (time.strftime("%Y-%m-%d %H:%M", time.gmtime(now - PST)),
                  "运行已经结束，主作业的结束状态是 %s，最后一条事件在 %s。" % (state_now, hms(main["last"])) if over
                  else "**运行还没有结束**，导出时主作业的状态是 %s；结束后的部分不在这份文件里。" % state_now))
    add("内容全部取自这次运行自己的记录（主持会话保存的会话、作业的事件和操作记录、各次模型调用的记录、启动记录、运行期间对节点请求的抽样），外加调度器的记账（只用于第 10 节的批次表），由脚本生成；"
        "事件、工具返回和 controller 写的理由与指示是英文原文，照原样保留。时间都是 PST（UTC−8），“第几分钟”从批处理作业启动算起。"
        "本机的路径、账户名、队列名、节点名、调度器作业编号、页面密钥和仓库所有者的姓名已经换成占位符。\n")
    add("和上一次（r1，不开性能验收）不同的地方：这次有两对作业（主持会话取消了第一对、重新提交了第二对，记作 ①、②），第二个主作业的测试设计做了两遍（冻结阶段暂停过一次），"
        "批处理作业到了时限、之后在新的批处理作业里恢复，以及性能验收本身（第 8 节）。\n")

    add("## 1. 配置和结束状态\n" if over else "## 1. 配置和目前的状态\n")
    resume_exit = re.search(r"resume: host exit=\d+ at (\S+)", launch)
    so_far = "" if over else "（到导出时）"
    last_full = full[-1] if full else None
    last_measure = measures[-1] if measures else None
    rows = [
        ["实验", "用 nanolize 压缩 detectron2（`%s` @ `%s`），从零开始：主持会话自己做完整的阶段 01，得到的功能图有 %d 项能力、%d 条检查；选核心能力：选中 %d 项，排除 %d 项，留下 %s 条检查"
         % (repo_commit.group(2), repo_commit.group(1)[:7], len(manifest.get("capabilities") or []), len(manifest.get("checks") or []),
            len(manifest.get("capabilities") or []) - len(sel.get("excluded") or []), len(sel.get("excluded") or []),
            ((done(main, "create_workspace") or [{}])[0].get("result") or {}).get("retained_checks"))],
        ["nanolize 代码", "%s，版本 %s" % (title, (main["config"].get("runtime") or {}).get("version"))],
        ["选项", "`%s`；并行模式的设置（原样）`%s`；性能验收的设置（原样）`%s`；检查经 nanolize 自己的执行器上计算节点"
         % (mask(re.search(r"args=(.*)", launch).group(1).strip()), json.dumps(parallel, ensure_ascii=False), json.dumps(perf_settings, ensure_ascii=False))],
        ["独立性", "不用任何早先运行的产物：detectron2 从公开仓库重新克隆到同一个提交；主持会话是全新的会话，功能图、清单、恢复的测试、runner 设置都由它重新做；"
                "整次运行在一个看不到早先运行文件（归档、包、运行记录、分析目录、Claude Code 的历史会话和记忆、节点上别人留下的临时文件）的挂载命名空间里。测试环境和预编译的 C++ 扩展是实验前用脚本建好的机器环境，不是任何一次运行的产物"],
        ["主持会话", "Claude Code %s，Fable 5.2，effort high；%s 启动；第一段到 %s 自己结束（%d 轮，$%.2f）；批处理作业到时后，%s 在新的批处理作业里用同一个会话继续，%s"
         % (claude, hms(started), hms(t_host_exit), sum(e.get("num_turns") or 0 for e in host_results), sum((e.get("total_cost_usd") or 0) for e in host_results[-1:]), hms(t_resume_host),
            "到 %s 结束（%d 轮，$%.2f）" % (hms(stamp(resume_exit.group(1))), sum(e.get("num_turns") or 0 for e in resume_results), sum((e.get("total_cost_usd") or 0) for e in resume_results[-1:]))
            if resume_exit and resume_results else "导出时还在值守")],
        ["作业", "；".join("%s作业 `%s`（%s）" % (name[job["id"]], job["id"][:8], job["public"].get("status")) for job in jobs)],
        ["结束状态" if over else "导出时的状态", "主作业② %s；最后一条事件 %s：%s" % (state_now, hms(main["last"]), one_line(main["events"][-1].get("message") or "", 300))],
        ["花费" + so_far, "作业里的模型调用 $%.2f（开始 %d 次，已结束 %d 次），试调 $%.2f（%d 次），%s；其中第一对作业 $%.2f，第二对作业 $%.2f"
         % (sum(c["cost"] for c in real), len(real), sum(1 for c in real if c["ended"]), sum(c["cost"] for c in trials), len(trials),
            "主持会话两段共 $%.2f" % host_cost if resume_results else "主持会话第一段 $%.2f（续跑的一段还没有结算）" % host_cost,
            sum(cost_of(job) for pair in old for job in pair), cost_of(main) + cost_of(draft))],
    ]
    if last_full:
        size = (last_full["result"].get("size") or {})
        rows.append(["行为验收" + so_far, "最后一次完整对比 `%s`（%s，%s）：`%s`，失败的检查 %s 条；体积 %s → %s token，保留 %.2f%%"
                     % (last_full["result"].get("artifact"), last_full.get("candidate"), hms(op_end(last_full)), last_full.get("outcome"), last_full["result"].get("failed_checks_total"),
                        format(size.get("baseline_tokens") or 0, ","), format(size.get("total_tokens") or 0, ","), size.get("retained_percent") or 0)])
    if installs:
        rows.append(["安装检查", "最近一次（%s，%s）：`%s`，%s / %s 步" % (installs[-1].get("candidate"), hms(op_end(installs[-1])), installs[-1].get("outcome"),
                                                             installs[-1]["result"].get("checks_passed"), installs[-1]["result"].get("checks_total"))])
    if last_measure:
        res = last_measure["result"]
        rows.append(["性能验收" + so_far, "做了 %d 次性能测量；最近一次 `%s`（%s，%s 结束，%.1f 分钟）：`%s`，%s 条标准里通过 %s 条，慢于允许值的 %s 条"
                     % (len(measures), res.get("artifact"), last_measure.get("candidate"), hms(op_end(last_measure)), last_measure["duration_seconds"] / 60,
                        last_measure.get("outcome"), res.get("criteria"), res.get("passed"), res.get("slower"))])
    rows.append(["原测试的迁移", "给了 %s 条，迁移成 %s 条；没能验证的 %s 条" % (migration.get("given"), migration.get("migrated"), migration.get("unverified"))])
    add(table(["项目", "内容"], rows))

    add("## 2. 时间账\n")
    add("按先后排的每一段。标了“作废”的是后来重做、没有用上的时间；“空档”是没有任何作业在工作的时间。\n")
    ledger = []
    seg = lambda label, a, z, note="": ledger.append([label, hms(a), hms(z), span(a, z), note]) if a and z and z >= a else None
    first_job = jobs[0]
    seg("主持会话的阶段 01 和提交（批处理作业启动到第一条作业事件）", started, first_job["first"])
    for index, (m, d) in enumerate(old):
        seg("第 %s 对作业（主持会话取消）" % marks[index], m["first"], m["last"], "作废")
        nxt = pairs[index + 1][0]
        seg("主持会话改清单、重新转换和规划、提交下一对", m["last"], nxt["first"])
    first_design = designs[0] if designs else None
    if first_design:
        seg("主②：试调 runner、建工作树、第一次基线", main["first"], op_start(first_design))
    for index, op in enumerate(designs):
        if op.get("outcome") == "done":
            seg("主②：测试设计第 %d 遍（完成）" % (index + 1), op_start(op), op_end(op))
        else:
            seg("主②：测试设计第 %d 遍（%s：%s）" % (index + 1, op.get("error"), one_line(op.get("message") or "", 120)), op_start(op), op_end(op), "作废")
            nxt = designs[index + 1] if index + 1 < len(designs) else None
            if nxt:
                seg("主②：暂停，主持会话恢复它", op_end(op), op_start(nxt), "空档")
    if design_op and seal:
        after = [op for op in baselines if op_start(op) >= op_end(design_op)]
        if after:
            seg("主②：带着设计出的测试重新抓基线", op_start(after[0]), op_end(after[0]))
            seg("主②：封存契约", op_end(after[0]), op_end(seal))
    if imports and seal:
        seg("主②：等草稿并导入", op_end(seal), op_end(imports[0]))
        end_fix = op_end(passed) if passed else now
        if t_killed and accepted_again and op_end(imports[0]) < t_killed < end_fix:
            seg("主②：对比和修复（到批处理作业到时）", op_end(imports[0]), t_killed)
            seg("批处理作业到时，到主作业在新的批处理作业里恢复", t_killed, stamp(accepted_again["time"]), "空档")
            seg("主②：恢复后的对比和修复（到全部行为检查通过）" if passed else "主②：恢复后的对比和修复（进行中）", stamp(accepted_again["time"]), end_fix)
        else:
            seg("主②：对比和修复（到全部行为检查通过）" if passed else "主②：对比和修复（进行中）", op_end(imports[0]), end_fix)
    if passed:
        cursor = op_end(passed)
        later = sorted([op for op in installs + measures if op_start(op) >= cursor - 1], key=op_start)
        before = None
        for op in later:
            if op_start(op) - cursor > 20:      # what ran between two of them: a repair, or the controller's next round
                if before is not None and before["tool"] == "compare_performance" and before.get("outcome") == "failed":
                    seg("主②：性能修复（controller、作者、准备环境、全量对比）", cursor, op_start(op))
                elif before is not None and before["tool"] == "compare_performance":
                    seg("主②：controller 的下一轮（选候选、尝试交付、决定再测）", cursor, op_start(op))
                else:
                    seg("主②：两步之间", cursor, op_start(op))
            before = op
            if op["tool"] == "check_installation":
                seg("主②：安装检查（%s）" % op.get("candidate"), op_start(op), op_end(op))
            else:
                seg("主②：性能测量 `%s`（%s，%s）" % (op["result"].get("artifact"), op.get("candidate"), op.get("outcome")), op_start(op), op_end(op))
            cursor = op_end(op)
        if over:
            seg("主②：最后一步之后到作业结束（选定候选、交付、交付后回放原测试）", cursor, main["last"])
        else:
            seg("主②：之后到导出时（进行中）", cursor, now)
    for index, (m, d) in enumerate(pairs):
        if d:
            seg("（同时）草稿%s作业，从它的第一条事件到最后一条" % marks[index], d["first"], d["last"], d["public"].get("status") or "")
    add(table(["阶段", "开始", "结束", "分钟", "备注"], ledger))
    wasted = sum(float(row[3]) for row in ledger if row[4] in ("作废", "空档"))
    if over:
        add("从批处理作业启动到主作业的最后一条事件共 %.0f 分钟，其中标为作废或空档的 %.0f 分钟。\n" % ((main["last"] - started) / 60, wasted))
    else:
        add("到导出时，批处理作业启动以来共 %.0f 分钟，其中标为作废或空档的 %.0f 分钟。\n" % ((now - started) / 60, wasted))

    add("## 3. 三次重来和中断\n")
    for index, (m, d) in enumerate(old):
        cancel = next((e for e in m["events"] if e.get("phase") == "cancel_requested"), {})
        add("**第 %d 次：主持会话取消第 %s 对作业（%s）。** 主作业%s `%s` 和草稿作业 `%s` 运行了 %s 分钟后被主持会话取消（事件原文：`%s`），花掉 $%.2f 的模型调用。"
            "原因和它改了什么，见主持会话在 issues.md 里的记录（第 4 节末尾）；之后它重新转换清单、重新规划，提交了下一对作业。\n"
            % (index + 1, marks[index], hms(stamp(cancel.get("time")) if cancel else m["last"]), marks[index], m["id"][:8], d["id"][:8] if d else "–", span(m["first"], m["last"]),
               one_line(cancel.get("message") or "", 200), cost_of(m) + cost_of(d)))
    number = len(old) + 1
    failed_design = next((op for op in designs if op.get("outcome") != "done"), None)
    if paused and failed_design:
        add("**第 %d 次：主作业②在冻结阶段暂停，测试设计重做（%s）。** 测试设计这一步开始 %s 分钟后，作业提交一个检查批次时调度器命令超时，作业暂停（事件原文：`%s`）。"
            "主持会话 %s 恢复了它（事件原文：`%s`）。这一步没有做完，恢复后从头重做：操作记录里第一遍是 `%s`（`%s`，%.1f 分钟），第二遍 %.1f 分钟。\n"
            % (number, hms(stamp(paused["time"])), span(op_start(failed_design), op_end(failed_design)), one_line(paused.get("message") or "", 500),
               hms(stamp(after_pause["time"])) if after_pause else "–", one_line((after_pause or {}).get("message") or "", 300),
               failed_design.get("status"), failed_design.get("error"), failed_design["duration_seconds"] / 60, (design_op.get("duration_seconds") or 0) / 60))
        number += 1
    if t_killed:
        preflight = (run / "resume-preflight.json").read_text().strip() if (run / "resume-preflight.json").exists() else ""
        add("**第 %d 次：批处理作业到了时限（%s）。** 整次运行所在的批处理作业有 14 小时的时限，到时后节点上的所有进程被结束（主持会话已在 %s 自己结束）。"
            "%s 在一个新的批处理作业里继续：先用 nanolize 自己的状态查询确认主作业可以恢复（返回 `%s`），再让同一个主持会话接着跑，由它调用恢复。"
            "作业事件原文：`%s`；`%s`。没有重新克隆、重做阶段 01 或提交新作业。\n"
            % (number, hms(t_killed), hms(t_host_exit), hms(t_resumed), one_line(preflight, 400),
               one_line((worker_lost or {}).get("message") or "", 200), one_line((accepted_again or {}).get("message") or "", 200)))

    add("## 4. 主持会话的轨迹\n")
    add("主持会话是一个无人值守的 Claude Code 会话（`claude -p`，带 nanolize 插件），在计算节点上按 nanolize 的 skill 做完阶段 01、启动评审、提交选择，然后定时查看作业。"
        "下面依次是给它的提示、启动记录、它每次传给 `start_execution_review` 的参数、续跑时给它的提示、它的每一步（调用了什么，说了什么；工具返回的内容不列）。\n")
    prompt = (run / "host-prompt.txt").read_text() if (run / "host-prompt.txt").exists() else ""
    add(details("给主持会话的提示（原文）", mask(prompt).strip()))
    add(details("启动记录（含续跑的几行）", mask("\n".join(line[:500] for line in launch.splitlines())).strip()))
    for index, (at, given) in enumerate(reviews, 1):
        add(details("第 %d 次传给 start_execution_review 的参数（%s）" % (index, hms(at)), mask(json.dumps(given, indent=1, ensure_ascii=False)), "json"))
    if (run / "host-resume-prompt.txt").exists():
        add(details("续跑时给主持会话的提示（原文）", mask((run / "host-resume-prompt.txt").read_text()).strip()))
    listed, marked = [], False
    for at, kind, what in steps:
        if t_resume_host and not marked and at and at >= t_resume_host:
            listed.append([hms(t_resume_host), plus(t_resume_host), "续跑", "**批处理作业到时之后，在新的批处理作业里用同一个会话继续（提示见上）**"])
            marked = True
        listed.append([hms(at), plus(at), kind, one_line(what, 1500) if kind == "说" else call_text(*what)])
    add(table(["时间", "第几分钟", "类型", "内容"], listed))
    if (work / "issues.md").exists():
        add(details("主持会话写的 issues.md（它在运行中记下的问题和决定，原文）", mask((work / "issues.md").read_text()).strip()))

    add("## 5. 四个作业的事件和操作（按时间）\n")
    add("“事件”是作业写给人看的进度消息；“操作”是作业执行的一步（工具名、结果、用时）；“controller”是 controller 的一轮决定。四个作业的记录合在一起按时间排。\n")
    rows = []
    for job in jobs:
        for event in job["events"]:
            rows.append((stamp(event["time"]), name[job["id"]], "事件", ("`%s` " % "、".join(event["codes"]) if event.get("codes") else "") + "[%s] " % event.get("phase") + one_line(event.get("message") or "", 900)))
        for op in ops[job["id"]]:
            took = "%.0f 秒" % op["duration_seconds"] if op.get("duration_seconds") is not None else "没有执行"
            extra = ""
            reason = (op.get("result") or {}).get("reason")
            if op.get("outcome") in ("invalid", "skipped", "not_triggered", "blocked") and reason:
                extra = "：" + one_line(reason, 400)
            if op.get("error"):
                extra += "：`%s` %s" % (op.get("error"), one_line(op.get("message") or "", 300))
            rows.append((op_start(op), name[job["id"]], "操作", "`%s` → %s（%s）%s%s%s" % (
                op["tool"], op.get("outcome") or op.get("status"), took, "，候选 %s" % op["candidate"] if op.get("candidate") else "",
                "，由 %s 发起" % op.get("caller") if op.get("caller") else "", extra)))
    for job, entry in decisions:
        res = entry.get("result") or {}
        rows.append((stamp(entry.get("time")), name[job["id"]], "controller", "第 %s 轮（%s，%.0f 秒，%d 个调用：%s）：%s" % (
            res.get("round"), entry.get("outcome"), res.get("duration_seconds") or 0, len(res.get("calls") or []),
            "、".join("`%s`" % call.get("tool") for call in res.get("calls") or []), one_line(res.get("reason") or "", 1200))))
    rows.sort(key=lambda row: row[0] or 0)
    add(table(["时间", "第几分钟", "作业", "类型", "内容"], [[hms(t), plus(t), job, kind, text] for t, job, kind, text in rows]))

    add("## 6. 模型会话（每次调用）\n")
    add("“位置”是这次调用在作业目录里的位置：`design/round-N/<叶子>` 是第 N 轮的测试设计者，`design/review…` 是评审者，`design/call-2/…` 是测试设计第二遍里的同类会话，`authoring` 是作者，"
        "`implementation-workspaces/workspace-…/authoring` 是并行组里的一个作者，`controller/NNNN` 是 controller 的第 N 轮。没有结束时间的是批处理作业到时那一刻还在跑的会话。"
        "每个会话逐步的记录（每条命令和输出）不在这份文件里，在运行目录的 `model-calls/<编号>/events.jsonl`。\n")
    label = {"author": "作者", "controller": "controller", "designer": "测试设计者", "reviewer": "测试评审者"}
    add(table(["开始", "结束", "第几分钟", "作业", "角色", "位置", "秒", "轮数", "美元", "输入 token（含缓存）", "输出 token", "记录编号"],
              [[hms(c["start"]), hms(c["start"] + c["seconds"]) if c["ended"] else "–", plus(c["start"]), name.get(c["job"], "–"), ("试调：" if c["trial"] else "") + label.get(c["role"], c["role"]), mask(c["where"]),
                "%.0f" % c["seconds"], c["turns"], "%.2f" % c["cost"], format(c["input"], ","), format(c["output"], ","), "`%s`" % c["id"][:8]] for c in calls]))
    by_role = {}
    for c in real:
        row = by_role.setdefault((name.get(c["job"], "–"), c["role"]), {"calls": 0, "cost": 0.0, "seconds": 0.0, "output": 0})
        row["calls"] += 1
        row["cost"] += c["cost"]
        row["seconds"] += c["seconds"]
        row["output"] += c["output"]
    add(table(["作业", "角色", "调用次数", "美元", "会话时间合计（分钟）", "输出 token"],
              [[job, label.get(role, role), row["calls"], "%.2f" % row["cost"], "%.1f" % (row["seconds"] / 60), format(row["output"], ",")] for (job, role), row in sorted(by_role.items())]
              + [["合计", "不含试调和主持会话", len(real), "%.2f" % sum(c["cost"] for c in real), "%.1f" % (sum(c["seconds"] for c in real) / 60), format(sum(c["output"] for c in real), ",")]]))

    add("## 7. 测试设计和评审\n")
    add("开了性能验收以后，测试设计除了给没有有效测试的叶子设计测试，还给每个有自己独占源码的选中叶子设计性能文件（基准文件）。设计出的文件先试跑，再评审，没过的回到下一轮。"
        "下面按“第几遍、第几轮”列出会话；主作业①的设计随第一对作业一起作废，主作业②的第一遍因暂停作废，用上的是第二遍。\n")
    groups = {}
    for c in real:
        if c["role"] not in ("designer", "reviewer"):
            continue
        found = re.match(r"design/(?:(call-\d+)/)?(round-\d+|review(?:-\d+)?)", c["where"])
        if not found:
            continue
        key = (name.get(c["job"], "–"), found.group(1) or "call-1", found.group(2))
        row = groups.setdefault(key, {"n": 0, "cost": 0.0, "first": c["start"], "last": c["start"] + c["seconds"], "kind": c["role"]})
        row["n"] += 1
        row["cost"] += c["cost"]
        row["first"] = min(row["first"], c["start"])
        row["last"] = max(row["last"], c["start"] + c["seconds"])
    add(table(["作业", "第几遍", "轮或评审", "角色", "会话数", "开始", "结束", "美元"],
              [[job, "第 %s 遍" % call.split("-")[1], part, label[row["kind"]], row["n"], hms(row["first"]), hms(row["last"]), "%.2f" % row["cost"]]
               for (job, call, part), row in sorted(groups.items(), key=lambda item: item[1]["first"])]))
    sessions, committed = design.get("sessions") or {}, design.get("committed") or {}
    reasons = {}
    for item in designed.get("rejected") or []:
        code = (item.get("reasons") or ["?"])[0]
        reasons[code] = reasons.get(code, 0) + 1
    add("主作业②用上的那一遍（第二遍）的结果：\n")
    add(table(["项目", "数量"], [
        ["作业记下的会话数（原样）", "`%s`" % json.dumps(sessions, ensure_ascii=False)],
        ["提交到原版上的设计文件", "%s 个测试文件 + %s 个场景文件 + %s 个性能文件" % (committed.get("tests"), committed.get("scenarios"), committed.get("performance"))],
        ["通过的文件（不含性能文件）", len(designed.get("accepted") or [])],
        ["被拒的文件（按原因）", "、".join("%s %d" % (k, v) for k, v in reasons.items()) or "无"],
        ["没有按评审意见改完的文件", len(designed.get("unrevised") or [])],
        ["留作固定测试（pinned）的文件", len(designed.get("pinned") or [])],
        ["原测试的迁移", "给了 %s 条，迁移成 %s 条，没法验证 %s 条" % (migration.get("given"), migration.get("migrated"), migration.get("unverifiable"))],
        ["各次基线的检查数", " → ".join(str((op.get("result") or {}).get("executed_checks")) for op in baselines)],
        ["第一次基线时没有有效测试的叶子", "、".join((baselines[0].get("result") or {}).get("leaves_without_valid_test") or []) or "无"] if baselines else ["第一次基线", "–"],
        ["封存时校验方持有的文件", ((seal or {}).get("result") or {}).get("protected_files")],
    ]))
    add("每个叶子的结果：\n")
    add(table(["叶子", "通过的测试文件", "通过的场景文件", "通过的性能文件", "固定测试", "被拒的测试（按原因）", "被拒的性能文件（按原因）", "原测试迁移 / 没验证"],
              [[leaf.get("leaf"), leaf.get("accepted"), (leaf.get("scenarios") or {}).get("accepted", "–"), (leaf.get("performance") or {}).get("accepted", "–"), leaf.get("pinned", "–"),
                "、".join("%s %d" % kv for kv in (leaf.get("rejected") or {}).items()) or "–",
                "、".join("%s %d" % kv for kv in ((leaf.get("performance") or {}).get("rejected") or {}).items()) or "–",
                "%s / %s" % ((leaf.get("migration") or {}).get("migrated", "–"), (leaf.get("migration") or {}).get("unverified", "–"))] for leaf in design.get("per_leaf") or []]))
    if design.get("per_leaf_omitted"):
        add("（作业的记录里另有 %s 个叶子没有逐个列出。）\n" % design.get("per_leaf_omitted"))
    if designed.get("rejected"):
        add("被拒的文件和理由（原文的开头）：\n")
        add(table(["叶子", "轮", "文件", "理由"], [[r.get("capability"), r.get("round"), "`%s`" % r.get("path"), one_line("；".join(str(x) for x in r.get("reasons") or []), 420)] for r in designed["rejected"]]))
    if designed.get("not_migrated"):
        add("没有迁移成的原测试：\n")
        add(table(["原测试", "叶子", "状态", "设计者给的理由"], [["`%s`" % r.get("test"), r.get("capability"), r.get("state"), one_line(r.get("reason") or "", 420)] for r in designed["not_migrated"]]))
    caps = ((seal or {}).get("result") or {}).get("caps") or []
    if caps:
        add("封存时就定下的上限（这些缺口之后的工具关不掉，原样）：\n")
        add(table(["缺口", "原因", "涉及"], [[c.get("gap"), c.get("reason"), one_line(json.dumps({k: v for k, v in c.items() if k not in ("gap", "reason")}, ensure_ascii=False), 400)] for c in caps]))

    add("## 8. 性能验收\n")
    summary = contract.get("summary") or {}
    files = contract.get("files") or []
    add("性能契约在封存时和行为契约一起定下：每个基准文件由测试设计者写，在冻结阶段先在原版上试跑（原版、原版再一次、把这个叶子故意减慢一倍的原版），能测出减慢的函数才成为验收标准。"
        "之后每个通过了行为检查的候选都和原版在同一台机器上对比。计时基准比较耗时，计数基准比较某个操作被执行的次数。\n")
    add(table(["项目", "内容"], [
        ["设置（原样）", "`%s`" % json.dumps(contract.get("settings") or perf_settings, ensure_ascii=False)],
        ["基准文件", "%d 个：计时 %d 个，计数 %d 个" % (len(files), sum(1 for f in files if f.get("kind") == "time"), sum(1 for f in files if f.get("kind") == "count"))],
        ["基准函数 / 其中是验收标准的", "%s / %s" % (summary.get("benchmarks"), summary.get("criteria"))],
        ["有标准的叶子 / 契约里的叶子 / 没有标准的叶子", "%d / %s / %s" % (sum(1 for v in (contract.get("leaves") or {}).values() if v.get("criteria")), summary.get("leaves"), summary.get("leaves_without_criteria"))],
        ["不算标准的基准（按原因）", "`%s`" % json.dumps(summary.get("not_criteria"), ensure_ascii=False)],
        ["因为噪声放宽了允许值的", summary.get("widened")],
        ["冻结阶段试跑基准用的时间（契约记下的 `validation_seconds`）", "%.0f 秒（%.1f 分钟）" % (contract.get("validation_seconds") or 0, (contract.get("validation_seconds") or 0) / 60)],
    ]))
    declined = designed.get("performance_declined") or []
    skipped = designed.get("performance_not_designed") or {}
    if declined or skipped:
        add("没有性能标准的叶子和原因（设计者写的理由是原文）：\n")
        add(table(["叶子", "情况", "理由"], [[d.get("capability"), "设计者放弃", one_line(d.get("reason") or "", 500)] for d in declined]
                  + [[leaf, "不设计", "`%s`" % why] for leaf, why in skipped.items()]))
    per = {}
    for f in files:
        row = per.setdefault(f.get("capability"), {"time": 0, "count": 0, "files": [], "cases": []})
        row["files"].append(f.get("path", "").split("/")[-1])
        for case in f.get("cases") or []:
            row[f.get("kind")] = row.get(f.get("kind"), 0) + 1
            row["cases"].append((f.get("kind"), case))
    add("每个叶子的基准（点开看每个基准函数和它测的内容，原文）：\n")
    add(table(["叶子", "计时基准", "计数基准", "文件"], [[leaf, row["time"], row["count"], "、".join("`%s`" % p for p in row["files"])] for leaf, row in sorted(per.items())]))
    for leaf, row in sorted(per.items()):
        body = table(["函数", "类型", "是标准", "允许慢（%）", "原版噪声（%）", "测的内容"],
                     [["`%s`" % case.get("function"), {"time": "计时", "count": "计数"}.get(kind, kind), "是" if case.get("criterion") else "否（%s）" % case.get("reason", "–"),
                       case.get("allowed_percent", "–"), case.get("noise_percent", "–"), one_line(case.get("measures") or "", 400)] for kind, case in row["cases"]])
        add(folded("%s：%d 个基准" % (leaf, len(row["cases"])), body))
    if measures:
        add("候选的性能测量：\n")
        add(table(["开始", "结束", "第几分钟", "候选", "分钟", "结果", "标准", "通过", "慢于允许值", "出错 / 超时 / 无结论", "记录"],
                  [[hms(op_start(op)), hms(op_end(op)), plus(op_start(op)), op.get("candidate"), "%.1f" % (op["duration_seconds"] / 60), op.get("outcome"), op["result"].get("criteria"),
                    op["result"].get("passed"), op["result"].get("slower"), "%s / %s / %s" % (op["result"].get("error"), op["result"].get("timed_out"), op["result"].get("inconclusive")),
                    "`%s`" % op["result"].get("artifact")] for op in measures]))
        for op in measures:
            record = load(main["dir"] / "artifacts" / ((op["result"].get("artifact") or "") + ".json"))
            marks_ = record.get("benchmarks") or []
            slower = [b for b in marks_ if b.get("status") == "slower"]
            ratios = sorted(b["ratio"] for b in marks_ if isinstance(b.get("ratio"), (int, float)))
            if ratios:
                add("`%s`：%d 个计时基准里，候选耗时与原版之比的中位数 %.3f，最小 %.3f，最大 %.3f；比原版快的占 %.0f%%。测量本身用了 %.0f 秒。\n"
                    % (op["result"].get("artifact"), len(ratios), ratios[len(ratios) // 2], ratios[0], ratios[-1], 100 * sum(1 for r in ratios if r < 1) / len(ratios), record.get("duration_seconds") or 0))
            if slower:
                add("`%s` 里慢于允许值的标准：\n" % op["result"].get("artifact"))
                add(table(["叶子", "函数", "候选 / 原版", "允许慢（%）", "原版噪声（%）", "轮数", "时钟", "测的内容"],
                          [[b.get("capability"), "`%s`" % b.get("function"), "%.3f" % b.get("ratio", 0), b.get("allowed_percent"), b.get("noise_percent"), b.get("rounds"), b.get("clock"),
                            one_line(b.get("measures") or "", 300)] for b in slower]))
            others = [b for b in marks_ if b.get("status") not in ("passed", "slower")]
            if others:
                add("`%s` 里只测量、不算标准的基准：\n" % op["result"].get("artifact"))
                add(table(["叶子", "函数", "状态", "原因", "候选 / 原版"], [[b.get("capability"), "`%s`" % b.get("function"), b.get("status"), b.get("reason", "–"),
                                                                     "%.3f" % b["ratio"] if isinstance(b.get("ratio"), (int, float)) else "–"] for b in others]))
    else:
        add("到导出时还没有做过候选的性能测量。\n")

    add("## 9. 候选、对比和修复\n")
    add("作者的每次调用。并行组（`run_parallel_agents`）里的每个请求是一个作者会话，各在自己的工作区里写，写完由程序合并：\n")
    mode = {"initial": "第一版", "behavior_repair": "行为修复", "performance_repair": "性能修复", "optimization": "体积优化"}
    by_space = {}
    for c in real:
        found = re.search(r"(workspace-[0-9a-f]+)", c["where"])
        if c["role"] == "author" and found:
            by_space[found.group(1)] = c
    authors = []
    for job in jobs:
        for op in ops[job["id"]]:
            if op.get("duration_seconds") is None or op.get("outcome") in ("skipped", None):
                continue
            res, params, begin = op.get("result") or {}, op.get("params") or {}, op_start(op)
            if op["tool"] == "run_parallel_agents":
                asked = params.get("requests") or []
                for index, request in enumerate(res.get("requests") or []):
                    call = by_space.get(request.get("workspace_id"), {})
                    what = asked[index] if index < len(asked) else {}
                    changes = request.get("changes") or {}
                    authors.append([hms(call.get("start") or begin), plus(call.get("start") or begin), name[job["id"]], "并行组（%s）的请求 %s：%s" % (res.get("group"), request.get("request", index + 1), mode.get(request.get("mode"), request.get("mode"))),
                                    request.get("scope") or "、".join(what.get("capabilities") or []), "%.1f" % ((request.get("seconds") or 0) / 60), call.get("turns", "–"),
                                    "%.2f" % call["cost"] if call else "–", "+%s / 改 %s / 删 %s" % (changes.get("added"), changes.get("modified"), changes.get("removed")),
                                    request.get("candidate_id"), request.get("exit_code")])
                authors.append([hms(begin), plus(begin), name[job["id"]], "↑ 这个并行组整体（含合并）", "%d 个请求，冲突 %d 处" % (len(res.get("requests") or []), len(res.get("conflicts") or [])),
                                "%.1f" % (op["duration_seconds"] / 60), "–", "–", "–", res.get("candidate_id"), "–"])
            elif op["tool"] == "run_agent":
                call = next((c for c in real if c["role"] == "author" and "workspace-" not in c["where"] and c["job"] == job["id"] and begin - 5 <= c["start"] <= begin + op["duration_seconds"]), {})
                changes = res.get("changes") or {}
                authors.append([hms(begin), plus(begin), name[job["id"]], "单个作者：%s%s" % (mode.get(res.get("mode"), res.get("mode")), "（并行组之后的集成）" if params.get("role") == "implement" or res.get("mode") == "initial" else ""),
                                params.get("scope") or "、".join(params.get("capabilities") or []) or "整个选择", "%.1f" % (op["duration_seconds"] / 60), call.get("turns", "–"),
                                "%.2f" % call["cost"] if call else "–", "+%s / 改 %s / 删 %s" % (changes.get("added"), changes.get("modified"), changes.get("removed")), op.get("candidate") or "–", res.get("exit_code")])
    add(table(["开始", "第几分钟", "作业", "做什么", "范围或叶子", "分钟", "轮数", "美元", "文件（加 / 改 / 删）", "候选", "退出码"], authors))
    scope_word = {"full": "完整", "targeted": "针对性"}
    listed = []
    for job in jobs:
        for op in done(job, "compare_behavior"):
            res = op.get("result") or {}
            listed.append((op_start(op), [hms(op_start(op)), plus(op_start(op)), name[job["id"]], scope_word.get(res.get("scope"), res.get("scope")), op.get("candidate"),
                                          "%.1f" % (op["duration_seconds"] / 60), op.get("outcome"), res.get("failed_checks_total"), res.get("failures", "–"), res.get("unverified_checks", "–"),
                                          "%.2f%%" % ((res.get("size") or {}).get("retained_percent") or 0), "`%s`" % res.get("artifact")]))
    add("行为对比（四个作业的都列在这里）：\n")
    add(table(["开始", "第几分钟", "作业", "范围", "候选", "分钟", "结果", "失败的检查", "失败的用例", "没有运行的检查", "体积", "记录"], [row for _, row in sorted(listed, key=lambda item: item[0])]))
    for job in jobs:
        for op in done(job, "compare_behavior"):
            record = load(job["dir"] / "artifacts" / (((op.get("result") or {}).get("artifact") or "") + ".json"))
            checks = record.get("checks") or []
            checks = checks if isinstance(checks, list) else list(checks.values())
            failed = [c for c in checks if c.get("status") == "regressed"]
            if failed:
                listed = []
                for c in failed:
                    before, current = (c.get("baseline") or {}).get("case_status") or {}, (c.get("current") or {}).get("case_status") or {}
                    cases = sorted(k.split("::")[-1] for k, v in current.items() if v != before.get(k))
                    errors = {}
                    for error in ((c.get("current") or {}).get("case_errors") or {}).values():
                        key = "%s @ %s" % (error.get("type"), error.get("where") or error.get("origin"))
                        errors[key] = errors.get(key, 0) + 1
                    listed.append(["`%s`" % c.get("name"), "、".join(c.get("capabilities") or []),
                                   ("、".join("`%s`" % k for k in cases[:6]) + (" 等 %d 个" % len(cases) if len(cases) > 6 else "")) or "–",
                                   one_line("；".join("%s ×%d" % kv for kv in sorted(errors.items(), key=lambda kv: -kv[1])[:3]), 260) or "–"])
                add(folded("%s作业 `%s`（%s，%s对比，%s）里没过的 %d 条检查" % (name[job["id"]], op["result"].get("artifact"), op.get("candidate"), scope_word.get(op["result"].get("scope")), hms(op_end(op)), len(failed)),
                           table(["检查", "叶子", "结果变了的用例", "出错的类型和位置（次数）"], listed)))
    if installs:
        add("安装检查（主作业②）：\n")
        add(table(["开始", "第几分钟", "候选", "秒", "结果", "通过的步数"],
                  [[hms(op_start(op)), plus(op_start(op)), op.get("candidate"), "%.0f" % op["duration_seconds"], op.get("outcome"),
                    "%s / %s" % (op["result"].get("checks_passed"), op["result"].get("checks_total"))] for op in installs]))
    add("controller 的每一轮（理由和它交给作者的指示是原文）：\n")
    for job, entry in decisions:
        res = entry.get("result") or {}
        at = stamp(entry.get("time"))
        add("**%s作业第 %s 轮** · %s（第 %s 分钟）· %s · 用时 %.0f 秒 · %s token（其中缓存 %s）\n" % (
            name[job["id"]], res.get("round"), hms(at), plus(at), entry.get("outcome"), res.get("duration_seconds") or 0,
            format(res.get("tokens") or 0, ","), format(res.get("cached_input_tokens") or 0, ",")))
        add("- 它面对的建议：`%s`\n- 理由：%s\n- 它点的调用：\n" % (one_line(json.dumps(res.get("advice"), ensure_ascii=False), 400), one_line(res.get("reason") or "", 3000)))
        for index, call in enumerate(res.get("calls") or [], 1):
            params = dict(call.get("params") or {})
            instructions, requests = params.pop("instructions", None), params.pop("requests", None)
            add("  %d. `%s` %s%s\n" % (index, call.get("tool"), one_line(json.dumps(params, ensure_ascii=False), 900) if params else "",
                                       "（条件：%s）" % one_line(json.dumps(call.get("when") or call.get("after"), ensure_ascii=False), 200) if call.get("when") or call.get("after") else ""))
            if instructions:
                add("     " + details("交给作者的指示", "\n".join("     " + line for line in mask(instructions).splitlines())).replace("\n```", "\n     ```").replace("\n</details>", "\n     </details>"))
            for number, request in enumerate(requests or [], 1):
                request = dict(request)
                text = request.pop("instructions", "") or ""
                add("     - 请求 %d：`%s`\n" % (number, one_line(json.dumps(request, ensure_ascii=False), 500)))
                if text:
                    add("       " + details("交给这个作者的指示", "\n".join("       " + line for line in mask(text).splitlines())).replace("\n```", "\n       ```").replace("\n</details>", "\n       </details>"))
        if res.get("errors") or res.get("dropped"):
            add("- 被拒或丢掉的：`%s`\n" % one_line(json.dumps({"errors": res.get("errors"), "dropped": res.get("dropped")}, ensure_ascii=False), 900))
    commits = {}
    for op in ops[main["id"]]:
        binding = op.get("binding") or {}
        if binding.get("candidate") and binding.get("commit"):
            commits.setdefault(binding["candidate"], binding["commit"])
    ordered = sorted(commits.items(), key=lambda item: int(item[0].split("-")[1]))
    shown = 0
    for (a, ca), (b, cb) in zip(ordered, ordered[1:]):
        stat = git(git_dir, "diff", "--stat", ca, cb)
        if stat:
            if not shown:
                add("主作业②里相邻两个被对比过的候选之间改了什么：\n")
            shown += 1
            add("%s → %s：\n\n```\n%s\n```\n" % (a, b, mask(stat)))

    add("## 10. 节点申请\n")
    add("主作业的检查和性能测量发到计算节点上跑（草稿作业的检查在它自己所在的机器上跑，不要节点）。下面是运行期间每 10 秒抓一次得到的：每个分配接下的请求，时间是第一次看到的时间"
        "（`_run_checks` 是一批检查，`knockouts` 是敲除，`measure` 是性能测量或基准试跑，带 `refused` 的是节点拒收：这个分配剩下的时间不够，作业会另申请一个）。"
        "批处理作业到时之后有十几分钟没有抽样。\n")
    served = {}
    for entry in lines(run / "served-samples.jsonl"):
        if "served" in entry:
            row = served.setdefault(entry["batch"], {"items": []})
            row["items"].append((entry["time"], entry["served"]))
    add(table(["分配（作业/分配，各前 8 位）", "作业", "第一条请求", "最后一条请求", "接下的请求，按先后（时间）"],
              [[key, next((label_ for jid, label_ in name.items() if jid.startswith(key.split("/")[0])), "–"), hms(row["items"][0][0]), hms(row["items"][-1][0]),
                "、".join("`%s`（%s）" % (what, hms(at)) for at, what in row["items"])] for key, row in served.items()]))
    if accounting:
        add("调度器记账里这次运行的批处理作业（`d2m-*` 是整次运行所在的作业，`nanolize-checks-*` 是作业申请的检查节点；时间是 PST）：\n")
        add(table(["名字", "开始", "结束", "用时", "状态"], [[re.sub(r"(nanolize-checks-[0-9a-f]{8})[0-9a-f]*", r"\1", p[1]), p[2].replace("T", " ")[5:], p[3].replace("T", " ")[5:] if p[3] != "Unknown" else "（还在跑）", p[4],
                                                       re.sub(r" by \d+", "", p[5])] for p in accounting]))

    add("## 11. 收尾\n" if over else "## 11. 导出时的状态\n")
    for job in jobs:
        add("- %s作业 `%s`：`%s`（阶段 `%s`），%d 条事件，最后一条 %s：%s\n" % (name[job["id"]], job["id"][:8], job["public"].get("status"), job["public"].get("phase"), len(job["events"]),
                                                                  hms(job["last"]), one_line(job["events"][-1].get("message") or "", 400)))
    if over:
        size_, acceptance, progress = outcome.get("size") or {}, outcome.get("acceptance") or {}, outcome.get("rewrite_progress") or {}
        replay = {}                              # the job's own totals: a test counts once, whatever the number of its leaves
        for group, counts in ((outcome.get("original_replay") or {}).get("summary") or {}).items():
            if isinstance(counts, dict):
                replay.update({group + "." + key: value for key, value in counts.items() if isinstance(value, (int, float))})
            elif isinstance(counts, (int, float)):
                replay[group] = counts
        add("- 结束状态 `%s`：%s\n" % (main["public"].get("status"), one_line(mask(outcome.get("summary") or main["public"].get("error") or ""), 700)))
        add("- 选定并交付的候选：`%s`；行为验收 `%s`，体积验收 `%s`；主作业的作者尝试 %s 次（导入的第一版算 1 次，其中修复 %s 次）；结果分支上的提交 `%s`。\n" % (
            outcome.get("candidate"), progress.get("behavior_acceptance"), progress.get("size_acceptance"), progress.get("author_attempts"), progress.get("repair_attempts"),
            commits.get(outcome.get("candidate"), "–")))
        if size_:
            add("- 体积：原版 %s token（%s 行），交付 %s token（%s 行，%s 个源文件），保留 %.2f%%。\n" % (
                format(size_.get("baseline_tokens") or 0, ","), format(size_.get("baseline_source_lines") or 0, ","), format(size_.get("total_tokens") or 0, ","),
                format(size_.get("source_lines") or 0, ","), size_.get("source_files"), size_.get("retained_percent") or 0))
        if outcome.get("performance") is not None:
            verdict = outcome.get("performance") or {}
            add("- 性能验收（作业的结果）：`%s`；%s 个基准、%s 条标准，通过 %s 条，慢于允许值 %s 条，没有定论 %s 条，出错 %s 条，超时 %s 条；允许差距因噪声放宽的 %s 条；"
                "性能修复用了 %s 次（上限 %s 次）；%s 个叶子有标准。\n" % (
                    verdict.get("status"), verdict.get("benchmarks"), verdict.get("criteria"), verdict.get("passed"), verdict.get("slower"), verdict.get("inconclusive"),
                    verdict.get("error"), verdict.get("timed_out"), verdict.get("widened"), progress.get("performance_repair_attempts"), progress.get("max_performance_repairs"),
                    len(verdict.get("capabilities") or {})))
            add("  其余几项原样：`%s`\n" % one_line(mask(json.dumps({k: verdict.get(k) for k in ("leaves", "not_criteria", "repairs", "rolled_back_optimizations") if k in verdict}, ensure_ascii=False)), 900))
        add("- 缺口（作业的验收报告，原样）：%s\n" % ("" if acceptance.get("gaps") else "无"))
        for gap in acceptance.get("gaps") or []:
            add("  - `%s`：`%s`\n" % (gap, one_line(mask(json.dumps((acceptance.get("details") or {}).get(gap), ensure_ascii=False)), 700)))
        if outcome.get("not_criteria") is not None:
            add("- 不算验收标准的检查：`%s`\n" % one_line(mask(json.dumps(outcome.get("not_criteria"), ensure_ascii=False)), 400))
        for unknown in outcome.get("unknowns") or []:
            add("- controller 记下的未知项 `%s`（%s）：%s 卡在：%s\n" % (unknown.get("id"), unknown.get("status"), one_line(mask(unknown.get("question") or ""), 700),
                                                              one_line(mask(unknown.get("blocker") or ""), 500)))
        if replay:
            add("- 交付后回放原测试：保留的 %d 个测试里回放 %d 个，原版通过 %d 个、交付版本通过 %d 个，退步 %d 个；和内部名字绑在一起的 %d 个里回放 %d 个，原版通过 %d 个、交付版本通过 %d 个，退步 %d 个。"
                "回放了 %d 个测试文件，另有 %d 个文件没有回放。\n" % (
                    replay.get("kept.tests", 0), replay.get("kept.replayed", 0), replay.get("kept.original_passed", 0), replay.get("kept.candidate_passed", 0), replay.get("kept.regressed", 0),
                    replay.get("coupled.tests", 0), replay.get("coupled.replayed", 0), replay.get("coupled.original_passed", 0), replay.get("coupled.candidate_passed", 0),
                    replay.get("coupled.regressed", 0), replay.get("files", 0), replay.get("files_not_replayed", 0)))
        for text_ in acceptance.get("limitations") or []:
            add("- 作业自己写的限制（原文）：%s\n" % one_line(mask(text_), 400))
    else:
        add("- 到导出时还没有交付（性能修复上限 %s 次）；所以这份文件没有“收尾”一节，体积和验收的最终数字以运行结束后的记录为准。\n" % perf_settings.get("max_repairs"))
    add("- 原仓库里主持会话提交的恢复测试：`%s`。\n" % one_line(commit, 200))
    fingerprints = re.findall(r"test_env_fingerprint\w*=(\w+)", launch)
    if fingerprints:
        add("- 测试环境的指纹：启动时、批处理作业到时后、续跑开始时都是 `%s`%s。\n" % (fingerprints[0], "" if len(set(fingerprints)) == 1 else "（有不一致：%s）" % sorted(set(fingerprints))))
    if host_results:
        add(details("主持会话第一段的最后一条消息（原文）", mask(host_results[-1].get("result") or "").strip()))
    if resume_results:
        add(details("主持会话续跑那一段的最后一条消息（原文）", mask(resume_results[-1].get("result") or "").strip()))

    text = "\n".join(w)
    left = re.findall("|".join([re.escape(SECRET["user"][:6]) + r"\w*", "/home/", re.escape(shared), re.escape(SECRET["account"][:7]) + r"\w*", SECRET["queues"],
                                r"@[a-z0-9-]+\.(?:com|org|edu)\b", SECRET["node"], r"sk-ant-\w+", r"\b%d\b" % os.getuid(), "sbatch=/",
                                re.escape(SECRET["account"].replace("_", "-")), "-" + re.escape(shared.strip("/")) + "-", re.escape(shared.rstrip("/")) + r"\b",
                                re.escape(Path(runtime).parents[2].name),
                                r"\b%s\b" % re.escape(Path(store).name),
                                *[re.escape(p) for p in SECRET["people"]], *SECRET["numbers"]]), text)
    if left:
        for found in sorted(set(left))[:12]:
            at = text.find(found)
            print('LEFT', repr(found), '...', repr(text[max(0, at - 160):at + 80]))
        raise SystemExit('masking is incomplete: nothing was written')
    target.write_text(text, encoding="utf-8")
    print(target.name, len(text), "characters;", len(steps), "host steps;", len(rows), "events and operations;", len(calls), "model sessions;", len(decisions), "controller rounds;",
          len(served), "check allocations;", len(measures), "performance measurements;", len(accounting), "accounting rows")


if __name__ == "__main__":
    build(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]), sys.argv[5], sys.argv[6] if len(sys.argv) > 6 else None)
