#!/usr/bin/env python3
"""make_trajectory.py: one Markdown file holding the trajectory of one arm of batch d2ab (detectron2 on the nanolize of
PR #43 or of PR #45; two jobs, started by a script), in the order things happened: how the run was started, every event
and operation of the two jobs, every model session, every controller round, the candidates and their comparisons, the
node requests. The sections follow the tqdm trajectories of 2026-11-20 (tqdm-runN-main-COMMIT-trajectory.md).

Read from the run's own records only (the jobs' public records and operation journals, the records of the model
calls, the samples of the node requests, the launch record). Nothing is called, nothing is changed. Paths of this
machine, the account, the queue, node names and scheduler job numbers are masked in what is written.

usage: make_trajectory.py ARM OUT.md WORK_DIR RUN_DIR CLONE_GIT_DIR
  WORK_DIR       the archived working root (holds state/ and model-calls/)
  RUN_DIR        the experiment's record of the arm (launch.txt, review-args.json, served-samples.jsonl)
  CLONE_GIT_DIR  the .git of the archived clone (for what changed between candidates)"""
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

ARMS = {
    "a": {"commit": "af5b2c7", "what": "GitHub main `af5b2c7`（PR #43 的合并提交）", "other": "对照的另一组用 PR #45 的合并提交 `21d8a28`",
          "label": "pr43-af5b2c7", "title": "PR #43 版本"},
    "b": {"commit": "21d8a28", "what": "GitHub main `21d8a28`（PR #45 的合并提交；比 PR #43 多 PR #44、PR #45）", "other": "对照的另一组用 PR #43 的合并提交 `af5b2c7`",
          "label": "pr45-21d8a28", "title": "PR #45 版本"},
}


def load(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return {} if default is None else default


def lines(path):
    found = []
    try:
        for line in Path(path).read_text(errors="replace").splitlines():
            try:
                found.append(json.loads(line))
            except ValueError:
                continue
    except OSError:
        pass
    return found


def stamp(value):
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError):
        return None


hms = lambda t: time.strftime("%H:%M:%S", time.gmtime(t)) if t else "–"
SECRET = {}  # what of this machine must not be written: filled from the run's own records in main()


def mask(text):
    """Nothing of this machine in what is written: its paths, the account, the queue, node names, job numbers, keys."""
    text = str(text)
    for old, new in SECRET["paths"]:
        text = text.replace(old, new)
    text = re.sub(r"((?:key|token|secret|password)[\"']?\s*[=:]\s*[\"']?)[A-Za-z0-9_\-]{16,}", r"\1<已隐去>", text, flags=re.I)
    text = re.sub(re.escape(SECRET["shared"]) + r"[A-Za-z0-9._/-]*", "<共享盘路径>", text)
    text = re.sub(r"/tmp/claude-\d+/[A-Za-z0-9._/-]+", "<临时目录>", text)
    text = text.replace(SECRET["home"], "~")
    text = text.replace(SECRET["account"], "<账户>")
    text = re.sub(SECRET["queues"], "<队列>", text)
    text = text.replace(SECRET["user"], "<用户>")
    text = re.sub(SECRET["node"], "<节点>", text)
    text = re.sub(r"((?:[Ss]cheduler|batch|[Ss]lurm) job(?: id)?[ =:]+)\d{6,}", r"\1<调度作业>", text)
    text = re.sub(r"(\"(?:job_id|slurm_job)\": \")\d{6,}", r"\1<调度作业>", text)
    text = re.sub(r"(slurm_job=)\d+", r"\1<调度作业>", text)
    text = re.sub(r"(sbatch=)\S+", r"\1<调度器命令>", text)
    for number in SECRET.get("numbers") or ():
        text = text.replace(number, "<调度作业>")
    return text


def one_line(text, limit):
    text = re.sub(r"\s+", " ", mask(text)).strip()
    return text if len(text) <= limit else text[:limit].rstrip() + " …"


cell = lambda text: str(text).replace("|", "\\|").replace("\n", " ")


def table(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join(" --- " for _ in head) + "|"]
    out += ["| " + " | ".join(cell(c) for c in row) + " |" for row in rows]
    return "\n".join(out) + "\n"


def read_job(job_dir):
    public, config = load(job_dir / "public.json"), load(job_dir / "config.json")
    events = public.get("events") or []
    return {"id": job_dir.name, "dir": job_dir, "public": public, "config": config, "events": events,
            "role": (config.get("pair") or {}).get("role") or "single", "entries": lines(job_dir / "operations.jsonl"),
            "first": stamp(events[0]["time"]) if events else None, "last": stamp(events[-1]["time"]) if events else None}


def diff_stat(git_dir, a, b):
    try:
        out = subprocess.run(["git", "--git-dir", str(git_dir), "--no-pager", "diff", "--stat", a, b], capture_output=True, text=True, timeout=120)
        return out.stdout.rstrip() if out.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def build(arm, target, work, run, git_dir):
    spec = ARMS[arm]
    jobs = [read_job(Path(p).parent) for p in sorted(Path(work, "state/jobs/jobs").glob("*/public.json"))]
    main = next(job for job in jobs if job["role"] == "main")
    draft = next(job for job in jobs if job["role"] == "draft")
    name = {main["id"]: "主", draft["id"]: "草稿"}
    zero = main["first"]
    plus = lambda t: "–" if t is None else "%.1f" % ((t - zero) / 60)
    launch = (run / "launch.txt").read_text()
    args = load(run / "review-args.json")
    executor = args.get("check_executor") or {}
    home = str(Path.home())
    shared = "/" + str(work).split("/")[1] + "/"                      # the shared filesystem the working root is on
    store = re.match(r"(.*)/archive/", str(work)).group(1)
    live = store + "/live"
    runtime = re.search(r"runtime=(\S+)", launch).group(1)
    SECRET.update({
        "paths": [(live + "/nanolize-runs/detectron2/state/jobs/jobs/" + main["id"], "<主作业目录>"),
                  (live + "/nanolize-runs/detectron2/state/jobs/jobs/" + draft["id"], "<草稿作业目录>"),
                  (live + "/nanolize-runs/detectron2", "<工作根>"), (live + "/detectron2", "<原仓库>"),
                  (str(work), "<工作根>"), (runtime, "<nanolize 代码>")],
        "shared": shared, "home": home, "user": Path(home).name, "account": executor.get("account") or "\0",
        "queues": r"\b(?:%s|%s_(?:short|long))\b" % (re.escape(executor.get("partition") or "\0"), re.escape((executor.get("partition") or "\0").split("_")[0])),
        "node": r"\b[a-z]{2,6}\d?-\d{4,6}\b",
    })
    raw = launch + " ".join(str(event.get("message")) for job in jobs for event in job["events"])
    SECRET["numbers"] = sorted(set(re.findall(r"(?:[Ss]cheduler job|slurm_job=)\s*(\d{6,})", raw)))
    result = main["public"].get("result") or {}
    size, sel, manifest = result.get("size") or {}, main["config"].get("selection") or {}, main["config"].get("manifest") or {}

    ops = {}
    for job in (main, draft):
        ops[job["id"]] = [e for e in job["entries"] if e.get("kind") == "op"]
    decisions = [e for e in main["entries"] if e.get("kind") == "decision"]
    op_start = lambda op: stamp(op.get("started_at"))
    done = lambda job, tool: [op for op in ops[job["id"]] if op.get("tool") == tool and op.get("duration_seconds") is not None]

    # model calls
    calls = []
    for folder in sorted(Path(work, "model-calls").glob("*")):
        meta, res = load(folder / "metadata.json"), load(folder / "result.json")
        if not meta:
            continue
        space = str(meta.get("workspace") or "")
        found = re.search(r"/jobs/jobs/([0-9a-f]{32})/?(.*)$", space)
        trial = not found
        role = {"test_designer": "designer", "test_reviewer": "reviewer", "controller": "controller"}.get(meta.get("role"), "author" if meta.get("adapter") == "author" else meta.get("adapter"))
        where = "试调用的临时目录" if trial else re.sub(r"/?workspace$", "", found.group(2)) or "."
        usage = res.get("usage") or {}
        calls.append({"start": meta.get("started"), "seconds": res.get("seconds") or 0, "role": role, "trial": trial,
                      "job": found.group(1) if found else None, "where": where, "turns": res.get("turns"), "cost": res.get("cost_usd") or 0,
                      "input": usage.get("input_tokens") or 0, "output": usage.get("output_tokens") or 0, "cached": usage.get("cached_input_tokens") or 0,
                      "exit": res.get("exit_code"), "timed_out": res.get("timed_out")})
    calls.sort(key=lambda c: c["start"])
    real = [c for c in calls if not c["trial"]]
    trials = [c for c in calls if c["trial"]]

    # node requests, from the events of the main job
    nodes, pending = [], None
    for event in main["events"]:
        codes, text, at = event.get("codes") or [], event.get("message") or "", stamp(event["time"])
        if "batch_queued" in codes:
            asked = re.search(r"asked for (\d+) minutes, (\d+) CPUs? and (\d+) MB", text)
            pending = {"queued": at, "what": re.sub(r" waits for a compute node.*", "", text), "asked": asked.groups() if asked else ("?", "?", "?"), "wait": None}
            nodes.append(pending)
        elif "batch_started" in codes and pending:
            wait = re.search(r"about (\d+) s after", text)
            pending["wait"] = int(wait.group(1)) if wait else None
    waited = sum(node["wait"] or 0 for node in nodes) / 60

    seal = done(main, "seal_contract")[0]
    t_seal = op_start(seal) + seal["duration_seconds"]
    compares = done(main, "compare_behavior")
    t_first = op_start(compares[0])
    select = done(main, "select_candidate")[-1]
    t_select = op_start(select) + select["duration_seconds"]
    total = (main["last"] - zero) / 60
    replay = {}                                                           # the job's own totals: a sum over the capabilities counts a test once for each of its leaves
    for group, counts in ((result.get("original_replay") or {}).get("summary") or {}).items():
        if isinstance(counts, dict):
            for key, value in counts.items():
                if isinstance(value, (int, float)):
                    replay[group + "." + key] = value
    designed = load(main["dir"] / "designed-tests.json")
    design_op = (done(main, "design_leaf_tests") or [{}])[0]
    design = design_op.get("result") or {}
    migration = designed.get("migration") or {}
    last_full = [op for op in compares if (op.get("result") or {}).get("scope") == "full"][-1]
    last_record = load(main["dir"] / "artifacts" / ((last_full["result"].get("artifact") or "") + ".json"))
    last_checks = last_record.get("checks") or []
    last_checks = last_checks if isinstance(last_checks, list) else list(last_checks.values())
    passed = sum(1 for check in last_checks if check.get("status") == "passed")
    progress = result.get("rewrite_progress") or {}
    strategy = result.get("strategy") or {}
    claude = re.search(r"claude=(\S+)", launch).group(1)
    repo_commit = re.search(r"folder=\S+ commit=(\w+) branch=(\S+)", launch)
    started = stamp(re.search(r"started=(\S+)", launch).group(1))

    w = []
    add = w.append
    add("# detectron2 压缩实验的轨迹：%s，nanolize main `%s`\n" % (spec["title"], spec["commit"]))
    add("这份文件按时间顺序记录这次实验里发生的每一步：运行是怎么启动的、两个作业的每条事件和每个操作、每个模型会话、controller 的每一轮、每个候选和它的对比、每个节点申请。"
        "内容全部取自这次运行自己的记录（作业的事件和操作记录、各次模型调用的记录、启动记录、运行期间对节点请求的抽样），由脚本生成；事件和工具返回的原文是英文，照原样保留。"
        "时间都是 UTC，“第几分钟”从主作业的第一条事件算起。本机的路径、账户名、队列名、节点名和调度器作业编号已经换成占位符。章节的排法和 2026-11-20 那三份 tqdm 轨迹相同。\n")

    add("## 1. 配置和结果\n")
    add(table(["项目", "内容"], [
        ["实验", "用 nanolize 压缩 detectron2（`%s` @ `%s`），给定功能图（%d 项能力、%d 条检查），选核心能力：选中 %d 项，排除 %d 项，留下 %s 条检查"
         % (repo_commit.group(2), repo_commit.group(1)[:7], len(manifest.get("capabilities") or []), len(manifest.get("checks") or []),
            len(manifest.get("capabilities") or []) - len(sel.get("excluded") or []), len(sel.get("excluded") or []),
            (done(main, "create_workspace")[0].get("result") or {}).get("retained_checks"))],
        ["nanolize 代码", spec["what"] + "，版本 %s；%s" % ((main["config"].get("runtime") or {}).get("version"), spec["other"])],
        ["选项", "`unattended=on scope=%s effort=high pair=%s`，并行关（没有传 parallel），不做性能验收；检查经 nanolize 自己的执行器上计算节点" % (args.get("scope_preset"), args.get("pair"))],
        ["启动", "没有主持会话：脚本直接调用 `start_execution_review` 并提交选择，参数和 main 的主持会话传的相同（第 3 节）；%s UTC 启动；Claude Code %s，Fable 5.2" % (time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(started)), claude)],
        ["两个作业", "主作业 `%s`（冻结契约、验证、交付），草稿作业 `%s`（同时写第一版）" % (main["id"][:8], draft["id"][:8])],
        ["主作业起止", "%s – %s，实际 %.1f 分钟；事件里记下的等节点 %.1f 分钟，扣掉之后 %.1f 分钟" % (hms(zero), hms(main["last"]), total, waited, total - waited)],
        ["结束状态", "`%s`；缺口：%s" % (main["public"].get("status"), "、".join("`%s`" % g for g in (result.get("acceptance") or {}).get("gaps") or []) or "无")],
        ["花费", "$%.2f（%d 次调用），另有试调 $%.2f（%d 次）" % (sum(c["cost"] for c in real), len(real), sum(c["cost"] for c in trials), len(trials))],
        ["体积", "%s → %s token，%.2f%%（目标 %.0f%%）" % (format(size.get("baseline_tokens") or 0, ","), format(size.get("total_tokens") or 0, ","), size.get("retained_percent") or 0, size.get("target_percent") or 0)],
        ["行为验收", "最后一次完整对比 %d 条检查全部通过；行为修复 %s 轮；controller %s 轮" % (passed, progress.get("repair_attempts"), strategy.get("rounds"))],
        ["安装检查", "%s / %s 步通过" % ((result.get("installation") or {}).get("checks_passed"), (result.get("installation") or {}).get("checks_total"))],
        ["原测试的迁移", "给了 %s 条，迁移成 %s 条；没能验证的原测试函数 %s 个" % (migration.get("given"), migration.get("migrated"), migration.get("unverified"))],
        ["交付后回放原测试", "保留的 %d 个测试里 %d 个在交付版本上通过，退步 %d 个；和内部名字绑在一起的 %d 个里 %d 个通过"
         % (replay.get("kept.tests", 0), replay.get("kept.candidate_passed", 0), replay.get("kept.regressed", 0), replay.get("coupled.tests", 0), replay.get("coupled.candidate_passed", 0))],
    ]))

    add("## 2. 阶段\n")
    inside = lambda a, z: sum(max(0.0, min(z, node["queued"] + (node["wait"] or 0)) - max(a, node["queued"])) for node in nodes) / 60
    stages = [("冻结（作业开始到封存）", zero, t_seal), ("第一版（封存到第一次完整对比开始；第一版由草稿作业在冻结期间写好）", t_seal, t_first),
              ("对比与修复（到选定候选）", t_first, t_select), ("交付", t_select, main["last"])]
    add(table(["阶段", "开始", "结束", "实际（分钟）", "其中等节点", "扣掉等节点"],
              [[label, hms(a), hms(z), "%.1f" % ((z - a) / 60), "%.1f" % inside(a, z), "%.1f" % ((z - a) / 60 - inside(a, z))] for label, a, z in stages]
              + [["草稿作业（和冻结同时进行）", hms(draft["first"]), hms(draft["last"]), "%.1f" % ((draft["last"] - draft["first"]) / 60), "0.0", "%.1f" % ((draft["last"] - draft["first"]) / 60)]]))

    add("等节点只算了主作业事件里记下的那几次申请（探测和两次基线）；对比阶段另外两个分配的申请没有留下事件，等了多久查不到（第 8 节）。\n")
    add("## 3. 这次运行是怎么启动的\n")
    add("这次运行没有主持会话（tqdm 那三份轨迹的第 3 节是主持会话的每一步）。启动它的是一个脚本：在一个计算节点上还原 detectron2 的克隆和工作根（功能图、选择和测试环境用的是此前一次已交付的 detectron2 运行里主持会话写好并评审过的那一份），"
        "用这一组的 nanolize 代码调用 `start_execution_review`，提交选择，然后只等两个作业结束，中途不介入。下面是启动记录和传给 `start_execution_review` 的参数。\n")
    add("<details><summary>启动记录</summary>\n\n```\n%s\n```\n\n</details>\n" % mask("\n".join(line[:400] for line in launch.splitlines() if not line.startswith("submit "))).strip())
    add("<details><summary>传给 start_execution_review 的参数</summary>\n\n```json\n%s\n```\n\n</details>\n" % mask(json.dumps(args, indent=1, ensure_ascii=False)))

    add("## 4. 两个作业的事件和操作（按时间）\n")
    add("“事件”是作业写给人看的进度消息；“操作”是作业执行的一步（工具名、结果、用时）；“controller”是 controller 的一轮决定。主作业和草稿作业的记录合在一起按时间排。\n")
    rows = []
    for job in (main, draft):
        for event in job["events"]:
            rows.append((stamp(event["time"]), name[job["id"]], "事件", ("`%s` " % "、".join(event["codes"]) if event.get("codes") else "") + one_line(event.get("message") or "", 900)))
        for op in ops[job["id"]]:
            took = "%.0f 秒" % op["duration_seconds"] if op.get("duration_seconds") is not None else "没有执行"
            extra = ""
            reason = (op.get("result") or {}).get("reason")
            if op.get("outcome") in ("invalid", "skipped", "not_triggered") and reason:
                extra = "：" + one_line(reason, 300)
            ref = op.get("ref") or {}
            rows.append((op_start(op), name[job["id"]], "操作", "`%s` → %s（%s）%s%s%s" % (
                op["tool"], op.get("outcome"), took, "，候选 %s" % op["candidate"] if op.get("candidate") else "",
                "，第 %s 轮的第 %s 个调用" % (ref.get("round"), ref.get("index") + 1) if ref else "", extra)))
    for entry in decisions:
        res = entry.get("result") or {}
        at = stamp(entry.get("time"))
        rows.append((at, "主", "controller", "第 %s 轮（%s，%.0f 秒，%d 个调用：%s）：%s" % (
            res.get("round"), entry.get("outcome"), res.get("duration_seconds") or 0, len(res.get("calls") or []),
            "、".join("`%s`" % call.get("tool") for call in res.get("calls") or []), one_line(res.get("reason") or "", 1200))))
    rows.sort(key=lambda row: row[0])
    add(table(["时间", "第几分钟", "作业", "类型", "内容"], [[hms(t), plus(t), job, kind, text] for t, job, kind, text in rows]))

    add("## 5. 模型会话（每次调用）\n")
    add("“位置”是这次调用在作业目录里的位置：`design/round-N/<叶子>` 是第 N 轮的测试设计者，`design/review…` 是评审者，`authoring` 是作者，`controller/NNNN` 是 controller 的第 N 轮。\n")
    label = {"author": "作者", "controller": "controller", "designer": "测试设计者", "reviewer": "测试评审者"}
    add(table(["开始", "结束", "第几分钟", "作业", "角色", "位置", "秒", "轮数", "美元", "输入 token（含缓存）", "输出 token"],
              [[hms(c["start"]), hms(c["start"] + c["seconds"]), plus(c["start"]), name.get(c["job"], "–"), ("试调：" if c["trial"] else "") + label.get(c["role"], c["role"]), mask(c["where"]),
                "%.0f" % c["seconds"], c["turns"], "%.2f" % c["cost"], format(c["input"], ","), format(c["output"], ",")] for c in calls]))
    by_role = {}
    for c in real:
        row = by_role.setdefault(c["role"], {"calls": 0, "cost": 0.0, "seconds": 0.0, "output": 0})
        row["calls"] += 1
        row["cost"] += c["cost"]
        row["seconds"] += c["seconds"]
        row["output"] += c["output"]
    add(table(["角色", "调用次数", "美元", "会话时间合计（分钟）", "输出 token"],
              [[label.get(role, role), row["calls"], "%.2f" % row["cost"], "%.1f" % (row["seconds"] / 60), format(row["output"], ",")] for role, row in by_role.items()]
              + [["合计（不含试调）", len(real), "%.2f" % sum(c["cost"] for c in real), "%.1f" % (sum(c["seconds"] for c in real) / 60), format(sum(c["output"] for c in real), ",")]]))

    add("## 6. 测试设计和评审\n")
    sessions, committed = design.get("sessions") or {}, design.get("committed") or {}
    reasons = {}
    for item in designed.get("rejected") or []:
        code = (item.get("reasons") or ["?"])[0]
        reasons[code] = reasons.get(code, 0) + 1
    add(table(["项目", "数量"], [
        ["设计者会话 / 评审者会话", "%d / %d" % (sum(1 for c in real if c["role"] == "designer"), sum(1 for c in real if c["role"] == "reviewer"))],
        ["作业记下的会话数（原样）", "`%s`" % json.dumps(sessions, ensure_ascii=False)],
        ["提交到原版上的设计文件", "%s 个测试文件 + %s 个场景文件（性能文件 %s 个）" % (committed.get("tests"), committed.get("scenarios"), committed.get("performance"))],
        ["通过的文件", len(designed.get("accepted") or [])],
        ["被拒的文件（按原因）", "、".join("%s %d" % (k, v) for k, v in reasons.items()) or "无"],
        ["没有按评审意见改完的文件", len(designed.get("unrevised") or [])],
        ["原测试的迁移", "给了 %s 条，迁移成 %s 条，没法验证 %s 条" % (migration.get("given"), migration.get("migrated"), migration.get("unverifiable"))],
        ["第二次基线的检查数", (done(main, "capture_baseline")[1].get("result") or {}).get("executed_checks") if len(done(main, "capture_baseline")) > 1 else "–"],
        ["封存时校验方持有的文件", (seal.get("result") or {}).get("protected_files")],
    ]))
    add("每个叶子的结果：\n")
    add(table(["叶子", "通过的测试文件", "通过的场景文件", "被拒的测试（按原因）", "被拒的场景（按原因）", "原测试迁移 / 没验证"],
              [[leaf.get("leaf"), leaf.get("accepted"), (leaf.get("scenarios") or {}).get("accepted"),
                "、".join("%s %d" % kv for kv in (leaf.get("rejected") or {}).items()) or "–",
                "、".join("%s %d" % kv for kv in ((leaf.get("scenarios") or {}).get("rejected") or {}).items()) or "–",
                "%s / %s" % ((leaf.get("migration") or {}).get("migrated", "–"), (leaf.get("migration") or {}).get("unverified", "–"))] for leaf in design.get("per_leaf") or []]))
    if designed.get("rejected"):
        add("被拒的文件和理由（原文的开头）：\n")
        add(table(["叶子", "轮", "文件", "理由"], [[r.get("capability"), r.get("round"), "`%s`" % r.get("path"), one_line("；".join(str(x) for x in r.get("reasons") or []), 420)] for r in designed["rejected"]]))
    if designed.get("not_migrated"):
        add("没有迁移成的原测试：\n")
        add(table(["原测试", "叶子", "状态", "设计者给的理由"], [["`%s`" % r.get("test"), r.get("capability"), r.get("state"), one_line(r.get("reason") or "", 420)] for r in designed["not_migrated"]]))

    add("## 7. 候选、对比和修复\n")
    add("作者的每次调用（草稿作业写第一版，一个范围一次；主作业做修复）：\n")
    mode = {"initial": "第一版", "behavior_repair": "行为修复", "performance_repair": "性能修复", "optimization": "体积优化"}
    authors = []
    for job in (draft, main):
        for op in done(job, "run_agent"):
            res, params = op.get("result") or {}, op.get("params") or {}
            begin = op_start(op)
            call = next((c for c in real if c["role"] == "author" and begin - 5 <= c["start"] <= begin + op["duration_seconds"]), {})
            changes = res.get("changes") or {}
            authors.append([hms(begin), plus(begin), name[job["id"]], mode.get(res.get("mode"), res.get("mode")), params.get("scope") or "、".join(params.get("capabilities") or []),
                            "%.1f" % (op["duration_seconds"] / 60), call.get("turns", "–"), "%.2f" % call["cost"] if call else "–",
                            "+%s / 改 %s / 删 %s" % (changes.get("added"), changes.get("modified"), changes.get("removed")), res.get("exit_code")])
    add(table(["开始", "第几分钟", "作业", "做什么", "范围或叶子", "分钟", "轮数", "美元", "文件（加 / 改 / 删）", "退出码"], authors))
    add("行为对比：\n")
    add(table(["开始", "第几分钟", "范围", "候选", "分钟", "结果", "失败的检查", "没有运行的检查", "体积", "记录"],
              [[hms(op_start(op)), plus(op_start(op)), {"full": "完整", "targeted": "针对性"}.get(op["result"].get("scope"), op["result"].get("scope")), op.get("candidate"),
                "%.1f" % (op["duration_seconds"] / 60), op.get("outcome"), op["result"].get("failed_checks_total"), op["result"].get("unverified_checks"),
                "%.2f%%" % ((op["result"].get("size") or {}).get("retained_percent") or 0), "`%s`" % op["result"].get("artifact")] for op in compares]))
    for op in compares:
        record = load(main["dir"] / "artifacts" / ((op["result"].get("artifact") or "") + ".json"))
        checks = record.get("checks") or []
        checks = checks if isinstance(checks, list) else list(checks.values())
        failed = [c for c in checks if c.get("status") == "regressed"]
        if failed:
            add("`%s`（%s，%s对比）里没过的检查：\n" % (op["result"].get("artifact"), op.get("candidate"), {"full": "完整", "targeted": "针对性"}.get(op["result"].get("scope"))))
            listed = []
            for c in failed:
                before, now = (c.get("baseline") or {}).get("case_status") or {}, (c.get("current") or {}).get("case_status") or {}
                cases = sorted(k.split("::")[-1] for k, v in now.items() if v != before.get(k))
                listed.append(["`%s`" % c.get("name"), "、".join(c.get("capabilities") or []), "、".join("`%s`" % p for p in (c.get("test_nodes") or [])[:2]),
                               "、".join("`%s`" % k for k in cases[:8]) + (" 等 %d 个" % len(cases) if len(cases) > 8 else "") or "–"])
            add(table(["检查", "叶子", "测试文件", "结果变了的用例"], listed))
    add("安装检查：\n")
    add(table(["开始", "第几分钟", "候选", "秒", "结果", "通过的步数"],
              [[hms(op_start(op)), plus(op_start(op)), op.get("candidate"), "%.0f" % op["duration_seconds"], op.get("outcome"),
                "%s / %s" % (op["result"].get("checks_passed"), op["result"].get("checks_total"))] for op in done(main, "check_installation")]))
    add("controller 的每一轮（理由和它交给作者的指示是原文）：\n")
    for entry in decisions:
        res = entry.get("result") or {}
        at = stamp(entry.get("time"))
        add("**第 %s 轮** · %s（第 %s 分钟）· %s · 用时 %.0f 秒 · %s token（其中缓存 %s）\n" % (
            res.get("round"), hms(at), plus(at), entry.get("outcome"), res.get("duration_seconds") or 0,
            format(res.get("tokens") or 0, ","), format(res.get("cached_input_tokens") or 0, ",")))
        add("- 它面对的建议：`%s`\n- 理由：%s\n- 它点的调用：\n" % (one_line(json.dumps(res.get("advice"), ensure_ascii=False), 400), one_line(res.get("reason") or "", 3000)))
        for index, call in enumerate(res.get("calls") or [], 1):
            params = dict(call.get("params") or {})
            instructions = params.pop("instructions", None)
            add("  %d. `%s` %s%s\n" % (index, call.get("tool"), one_line(json.dumps(params, ensure_ascii=False), 500) if params else "",
                                       "（条件：%s）" % one_line(json.dumps(call.get("when") or call.get("after"), ensure_ascii=False), 200) if call.get("when") or call.get("after") else ""))
            if instructions:
                add("     <details><summary>交给作者的指示</summary>\n\n     ```\n%s\n     ```\n\n     </details>\n" % "\n".join("     " + line for line in mask(instructions).splitlines()))
        if res.get("errors") or res.get("dropped"):
            add("- 被拒或丢掉的：`%s`\n" % one_line(json.dumps({"errors": res.get("errors"), "dropped": res.get("dropped")}, ensure_ascii=False), 900))
    commits = {}
    for op in ops[main["id"]]:
        binding = op.get("binding") or {}
        if binding.get("candidate") and binding.get("commit"):
            commits.setdefault(binding["candidate"], binding["commit"])
    ordered = sorted(commits.items(), key=lambda item: int(item[0].split("-")[1]))
    if len(ordered) > 1:
        add("相邻两个候选之间改了什么（比较主作业保存的两个候选）：\n")
        for (a, ca), (b, cb) in zip(ordered, ordered[1:]):
            stat = diff_stat(git_dir, ca, cb)
            add("%s → %s：\n\n```\n%s\n```\n" % (a, b, mask(stat) if stat else "（读不到）"))

    add("## 8. 节点申请\n")
    add("主作业事件里记下的节点申请（草稿作业的检查在它自己所在的机器上跑，不要节点）。对比阶段另外两个分配的申请没有留下事件，只能在下面第二张表里看到它们接下的请求：\n")
    add(table(["提交", "第几分钟", "是什么", "申请时长（分钟）", "核", "内存（MB）", "等待（秒）"],
              [[hms(node["queued"]), plus(node["queued"]), one_line(node["what"], 200), node["asked"][0], node["asked"][1], node["asked"][2], node["wait"] if node["wait"] is not None else "–"] for node in nodes]))
    served = {}
    for entry in lines(run / "served-samples.jsonl"):
        if "served" in entry:
            row = served.setdefault(entry["batch"], {"first": entry["time"], "last": entry["time"], "served": []})
            row["last"] = entry["time"]
            row["served"].append(entry["served"])
    if served:
        add("每个分配接下和拒收的请求（运行期间每 10 秒抓一次，时间是第一次看到的时间；`_run_checks` 是一批检查，`knockouts` 是敲除，`run_each` 是交付后回放原测试，带 `refused` 的是节点拒收）：\n")
        add(table(["分配（作业/分配，各前 8 位）", "第一条请求", "最后一条请求", "接下和拒收的请求，按先后"],
                  [[key, "%s（第 %s 分钟）" % (hms(row["first"]), plus(row["first"])), "%s（第 %s 分钟）" % (hms(row["last"]), plus(row["last"])), "、".join("`%s`" % item for item in row["served"])] for key, row in served.items()]))

    add("## 9. 收尾\n")
    add("- 结束状态 `%s`：%s\n" % (main["public"].get("status"), one_line(result.get("summary") or "", 600)))
    add("- 选定并交付的候选：`%s`；行为验收 `%s`，体积验收 `%s`；主作业的作者尝试 %s 次（导入的第一版算 1 次，其中修复 %s 次）。\n" % (
        result.get("candidate"), progress.get("behavior_acceptance"), progress.get("size_acceptance"), progress.get("author_attempts"), progress.get("repair_attempts")))
    add("- 体积：原版 %s token（%s 行），交付 %s token（%s 行，%s 个源文件），保留 %.2f%%。\n" % (
        format(size.get("baseline_tokens") or 0, ","), format(size.get("baseline_source_lines") or 0, ","), format(size.get("total_tokens") or 0, ","),
        format(size.get("source_lines") or 0, ","), size.get("source_files"), size.get("retained_percent") or 0))
    add("- 交付后回放原测试：保留的 %d 个测试里 %d 个在原版上通过、%d 个在交付版本上通过，退步 %d 个；和内部名字绑在一起的 %d 个里原版通过 %d 个、交付版本通过 %d 个。\n" % (
        replay.get("kept.tests", 0), replay.get("kept.original_passed", 0), replay.get("kept.candidate_passed", 0), replay.get("kept.regressed", 0),
        replay.get("coupled.tests", 0), replay.get("coupled.original_passed", 0), replay.get("coupled.candidate_passed", 0)))
    add("- 草稿作业：结束状态 `%s`，%.1f 分钟写完 %d 个范围。\n" % (draft["public"].get("status"), (draft["last"] - draft["first"]) / 60, len(done(draft, "run_agent"))))
    for text in (result.get("acceptance") or {}).get("limitations") or []:
        add("- 作业自己写的限制（原文）：%s\n" % one_line(text, 400))

    text = "\n".join(w)
    left = re.findall("|".join([re.escape(SECRET["user"][:6]) + r"\w*", "/home/", re.escape(shared), re.escape(SECRET["account"][:7]) + r"\w*", SECRET["queues"],
                                r"@[a-z0-9-]+\.(?:com|org|edu)\b", SECRET["node"], r"sk-ant-\w+", r"\b%d\b" % os.getuid(), "sbatch=/", *SECRET["numbers"]]), text)
    assert not left, sorted(set(left))[:20]
    target.write_text(text, encoding="utf-8")
    print(target.name, len(text), "characters;", len(rows), "events and operations;", len(calls), "model sessions;", len(decisions), "controller rounds;", len(nodes), "node requests")


if __name__ == "__main__":
    build(sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]), Path(sys.argv[5]))
